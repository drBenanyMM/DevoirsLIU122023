package Metier;

public class Medicament{
	
}
