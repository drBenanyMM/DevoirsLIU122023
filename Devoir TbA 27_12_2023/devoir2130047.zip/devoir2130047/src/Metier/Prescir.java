package Metier;

public class Prescir {

}
