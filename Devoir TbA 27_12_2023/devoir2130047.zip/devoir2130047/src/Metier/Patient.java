package Metier;

public class Patient {
	public int Code;
	public String Nom;
	public String Prenom;
	public String Adress;
	public int Numtel;

	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Patient(int code, String nom, String prenom, String adress, int numtel) {
		super();
		Code = code;
		Nom = nom;
		Prenom = prenom;
		Adress = adress;
		Numtel = numtel;
	}

	public int getCode() {
		return Code;
	}

	public void setCode(int code) {
		Code = code;
	}

	public String getNom() {
		return Nom;
	}

	public void setNom(String nom) {
		Nom = nom;
	}

	public String getPrenom() {
		return Prenom;
	}

	public void setPrenom(String prenom) {
		Prenom = prenom;
	}

	public String getAdress() {
		return Adress;
	}

	public void setAdress(String adress) {
		Adress = adress;
	}

	public int getNumtel() {
		return Numtel;
	}

	public void setNumtel(int numtel) {
		Numtel = numtel;
	}

	@Override
	public String toString() {
		return "Medicament [Code=" + Code + ", Nom=" + Nom + ", Prenom=" + Prenom + ", Adress=" + Adress + ", Numtel="
				+ Numtel + ", getCode()=" + getCode() + ", getNom()=" + getNom() + ", getPrenom()=" + getPrenom()
				+ ", getAdress()=" + getAdress() + ", getNumtel()=" + getNumtel() + "]";
	}

}
