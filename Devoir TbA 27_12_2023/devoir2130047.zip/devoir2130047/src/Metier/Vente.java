package Metier;

public class Vente {

}
