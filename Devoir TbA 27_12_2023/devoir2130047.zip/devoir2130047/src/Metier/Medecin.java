package Metier;

public class Medecin {
	public int ID;
	public int Nom;
	public int Prenom;
	public int Specialite;

	public Medecin() {

	}

	public Medecin(int iD, int nom, int prenom, int specialite) {
		super();
		ID = iD;
		Nom = nom;
		Prenom = prenom;
		Specialite = specialite;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public int getNom() {
		return Nom;
	}

	public void setNom(int nom) {
		Nom = nom;
	}

	public int getPrenom() {
		return Prenom;
	}

	public void setPrenom(int prenom) {
		Prenom = prenom;
	}

	public int getSpecialite() {
		return Specialite;
	}

	public void setSpecialite(int specialite) {
		Specialite = specialite;
	}

	@Override
	public String toString() {
		return "Medecin [ID=" + ID + ", Nom=" + Nom + ", Prenom=" + Prenom + ", Specialite=" + Specialite
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

}
