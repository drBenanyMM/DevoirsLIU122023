package Dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import BDD.DbConnection;
import Metier.Medicament;

public class MedicamentDao implements dao<Medicament> {
	//les attribut 
	//la conexion avec la base de donnes
		
	    private Connection connection = null;
	    
	 //les statement
	     private Statement state = null;
	     private Medicament medicament = null;
	     private String requette = null;
	     
	 //les constructeur
	     public MedicamentDao() {
	      try {
	    	connection = DbConnection.getConnection();
			state =  connection.createStatement();
			//affieche erreur sql
		} catch (SQLException e) {
			e.printStackTrace();
		}
	     }
	     
	@Override
	public Medicament get(long id) {
	
		requette = "SELECT * FROM Medicament WHERE Code =" +id;
		System.out.println(requette);
		
		//execute la requette 
		 
		try {
		ResultSet rs = state.executeQuery(requette);
		
		
		//afficher la resut
		if(rs.next()) 
			do {
				int Code = rs.getInt("code");
				String Nom =  rs.getString("Nom");
			    String Dosage =  rs.getString("Dosage");
			    int Prix = rs.getInt("Prix");
			    String Stockage =  rs.getString("Stockage");
			    
				medicament = new Medicament (Code , Nom , Dosage , Prix , Stockage);
				
				//affichge dinstance
				System.out.println(medicament.toString());
				
			}
			while(rs.next());
		else throw new SQLException();
		
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return medicament;
	
	}

	//methode select tt la table 
	public List<Medicament> getAll() {
		ArrayList<Medicament> arraylist = new ArrayList<>();
		requette = "SELECT * FROM Medicament";
		System.out.println(requette);
		
		//execute la requette 
		 
		try {
		ResultSet rs = state.executeQuery(requette);
		
		
		//afficher la resut
		if(rs.next()) 
			do {
				int Code = rs.getInt("Code");
				String Nom =  rs.getString("Nom");
			    String Dosage  =  rs.getString("Dosage");
			    int Prix = rs.getInt("Prix");
			    String Stock  =  rs.getString("Stock");
			   
			    
				medicament = new Medicament(Code, Nom , Dosage , Prix , Stock );
				
				
				arraylist.add(medicament);
		
				System.out.println(medicament.toString());
				
			}
			while(rs.next());
		else throw new SQLException();
		
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return arraylist;
	}
		
		
	

	@Override
	public void save(Medicament t) {
	
		requette = "INSERT INTO MEdicament VALUES('" + t.getCode() +"','" + t.getNom() + "','" + t.getDosage() + "','" + t.getPrix() + "','" + t.getStock() + "')";
		System.out.println(requette);
		
		try {
			int rs = state.executeUpdate(requette);
			if(rs>0)
				System.out.println("Medicament enregistre");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	@Override
	public void update(Medicament t, String[] params) {
		requette = "UPDATE Medicament SET Code =  '" +params[1]+"' WHERE Code = " + t.getCode() + "";
		System.out.println(requette);
		
		try {
			int rs = state.executeUpdate(requette);
			if(rs>0)
				System.out.println("modification reussie");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(Medicament t) {
		// TODO Auto-generated method stub
		requette = "DELETE FROM Medicament WHERE Code =" + t.getCode();
		System.out.println(requette);
		
		try {
			int rs = state.executeUpdate(requette);
			if(rs>0)
				System.out.println("Medicament supprimer");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	public static void main(String[]args) {
	
			MedicamentDao medicamentDao = new MedicamentDao();


//	     	medicamentDao.get();
//			medicamentDao.save();
//	    medicamentDao.getAll();
//	        medicamentDao.delete();
	}
}
			
