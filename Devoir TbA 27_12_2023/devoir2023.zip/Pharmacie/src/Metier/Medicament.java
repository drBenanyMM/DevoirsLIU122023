package Metier;

public class Medicament {
	//les donnees
    private int code ;
    private String  Nom ;
    private String Dosage ;
    private int Prix ;
    private String stock;
    
    public Medicament() {}
	public Medicament(int code, String nomMEd, String dosage, int prix, String stock) {
		this.code = code;
		Nom = nomMEd;
		Dosage = dosage;
		Prix = prix;
		this.stock = stock;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getDosage() {
		return Dosage;
	}
	public void setDosage(String dosage) {
		Dosage = dosage;
	}
	public int getPrix() {
		return Prix;
	}
	public void setPrix(int prix) {
		Prix = prix;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	@Override
	public String toString() {
		return "Medicament [code=" + code + ", Nom=" + Nom + ", Dosage=" + Dosage + ", Prix=" + Prix + ", stock="
				+ stock + "]";
	}
    
    
    
    

}
