package Metier;

public class Pharmacie {

	 private int code ;
	    private String  NomPh ;
	    private String Emplacement ;
	    
		public Pharmacie(int code, String nomPh, String emplacement) {
			this.code = code;
			NomPh = nomPh;
			Emplacement = emplacement;
		}

		public int getCode() {
			return code;
		}

		public void setCode(int code) {
			this.code = code;
		}

		public String getNomPh() {
			return NomPh;
		}

		public void setNomPh(String nomPh) {
			NomPh = nomPh;
		}

		public String getEmplacement() {
			return Emplacement;
		}

		public void setEmplacement(String emplacement) {
			Emplacement = emplacement;
		}

		@Override
		public String toString() {
			return "Pharmacie [code=" + code + ", NomPh=" + NomPh + ", Emplacement=" + Emplacement + "]";
		}
	    
	    
	    
}
