package Metier;

public class Comprendre {
	private int code ;
    private int  Numtrans ;
	public Comprendre(int code, int numtrans) {
		this.code = code;
		Numtrans = numtrans;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getNumtrans() {
		return Numtrans;
	}
	public void setNumtrans(int numtrans) {
		Numtrans = numtrans;
	}
	@Override
	public String toString() {
		return "Comprendre [code=" + code + ", Numtrans=" + Numtrans + "]";
	}

    
}
