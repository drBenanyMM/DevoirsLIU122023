package Metier;

public class recevoir {
	private int code ;
    private int  IdP ;
	public recevoir(int code, int idP) {
		this.code = code;
		IdP = idP;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getIdP() {
		return IdP;
	}
	public void setIdP(int idP) {
		IdP = idP;
	}
	@Override
	public String toString() {
		return "recevoir [code=" + code + ", IdP=" + IdP + "]";
	}

    
}
