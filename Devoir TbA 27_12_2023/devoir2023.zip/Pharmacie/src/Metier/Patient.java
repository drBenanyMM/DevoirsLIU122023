package Metier;

public class Patient {
	 private int IdP ;
	    private String  NomP ;
	    private String prenomP ;
	    private int Adresse ;
	    private int Numero;
	    private String Telephone;
		public Patient(int idP, String nomP, String prenomP, int adresse, int numero, String telephone) {
			IdP = idP;
			NomP = nomP;
			this.prenomP = prenomP;
			Adresse = adresse;
			Numero = numero;
			Telephone = telephone;
		}
		public int getIdP() {
			return IdP;
		}
		public void setIdP(int idP) {
			IdP = idP;
		}
		public String getNomP() {
			return NomP;
		}
		public void setNomP(String nomP) {
			NomP = nomP;
		}
		public String getPrenomP() {
			return prenomP;
		}
		public void setPrenomP(String prenomP) {
			this.prenomP = prenomP;
		}
		public int getAdresse() {
			return Adresse;
		}
		public void setAdresse(int adresse) {
			Adresse = adresse;
		}
		public int getNumero() {
			return Numero;
		}
		public void setNumero(int numero) {
			Numero = numero;
		}
		public String getTelephone() {
			return Telephone;
		}
		public void setTelephone(String telephone) {
			Telephone = telephone;
		}
		@Override
		public String toString() {
			return "Patient [IdP=" + IdP + ", NomP=" + NomP + ", prenomP=" + prenomP + ", Adresse=" + Adresse
					+ ", Numero=" + Numero + ", Telephone=" + Telephone + "]";
		}
	    
	    
}
