package Metier;

public class Vente {
	 private int code ;
	    private String  Numtrans ;
	    private String Datee ;
	    private int Montant ;
		public Vente(int code, String numtrans, String datee, int montant) {
			this.code = code;
			Numtrans = numtrans;
			Datee = datee;
			Montant = montant;
		}
		public int getCode() {
			return code;
		}
		public void setCode(int code) {
			this.code = code;
		}
		public String getNumtrans() {
			return Numtrans;
		}
		public void setNumtrans(String numtrans) {
			Numtrans = numtrans;
		}
		public String getDatee() {
			return Datee;
		}
		public void setDatee(String datee) {
			Datee = datee;
		}
		public int getMontant() {
			return Montant;
		}
		public void setMontant(int montant) {
			Montant = montant;
		}
		@Override
		public String toString() {
			return "Vente [code=" + code + ", Numtrans=" + Numtrans + ", Datee=" + Datee + ", Montant=" + Montant + "]";
		}
	   
	    

}
