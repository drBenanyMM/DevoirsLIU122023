package Metier;

public class Medecin {
	
	 private int code ;
	    private String  Id ;
	    private String NomMed ;
	    private int PrenomMed ;
	    private String Specialite;
		public Medecin(int code, String id, String nomMed, int prenomMed, String specialite) {
			this.code = code;
			Id = id;
			NomMed = nomMed;
			PrenomMed = prenomMed;
			Specialite = specialite;
		}
		public int getCode() {
			return code;
		}
		public void setCode(int code) {
			this.code = code;
		}
		public String getId() {
			return Id;
		}
		public void setId(String id) {
			Id = id;
		}
		public String getNomMed() {
			return NomMed;
		}
		public void setNomMed(String nomMed) {
			NomMed = nomMed;
		}
		public int getPrenomMed() {
			return PrenomMed;
		}
		public void setPrenomMed(int prenomMed) {
			PrenomMed = prenomMed;
		}
		public String getSpecialite() {
			return Specialite;
		}
		public void setSpecialite(String specialite) {
			Specialite = specialite;
		}
		@Override
		public String toString() {
			return "Medecin [code=" + code + ", Id=" + Id + ", NomMed=" + NomMed + ", PrenomMed=" + PrenomMed
					+ ", Specialite=" + Specialite + "]";
		}
	    
	    

}
