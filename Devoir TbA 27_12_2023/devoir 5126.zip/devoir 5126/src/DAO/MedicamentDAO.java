package DAO;

public class MedicamentDAO {

}
