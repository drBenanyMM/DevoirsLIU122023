package DAO;

public class VendreDAO {

}
