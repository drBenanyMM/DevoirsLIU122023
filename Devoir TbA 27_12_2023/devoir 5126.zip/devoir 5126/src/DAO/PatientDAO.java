package DAO;

public class PatientDAO {

}
