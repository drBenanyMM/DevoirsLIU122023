package DAO;

public class MedecinDAO {

}
