package DAO;

public class Pharmacie {

}
