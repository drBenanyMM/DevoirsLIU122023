package metier;

public class Pharmacie {

}
