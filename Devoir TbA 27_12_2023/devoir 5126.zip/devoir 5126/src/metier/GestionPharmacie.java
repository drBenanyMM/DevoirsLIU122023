package metier;

public class Pharmacie {
	public String Nom;
	public String Emplacement;

	public Pharmacie() {

	}

	public Pharmacie(String nom, String emplacement) {
		super();
		Nom = nom;
		Emplacement = emplacement;
	}

	public String getNom() {
		return Nom;
	}

	public void setNom(String nom) {
		Nom = nom;
	}

	public String getEmplacement() {
		return Emplacement;
	}

	public void setEmplacement(String emplacement) {
		Emplacement = emplacement;
	}

	@Override
	public String toString() {
		return "Pharmacie [Nom=" + Nom + ", Emplacement=" + Emplacement + ", getNom()=" + getNom()
				+ ", getEmplacement()=" + getEmplacement() + "]";
	}

}