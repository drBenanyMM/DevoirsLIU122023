package Bdd;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public Class Connection {
	private static Connection instance;
	private Connection connection;
	private String url = "jdbc:mysql://localhost:3306/gestionDebibliotheque";
	private String username = "root";
	private String password = "";


	private connection() throws SQLException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			this.connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection etablie");
		} catch (ClassNotFoundException ex) {
			System.out.println("Something is wrong with the DB connection String : " + ex.getMessage());
		}
	}

	public Connection getConnection() {
		return connection;
	}

	public static connection getInstance() throws SQLException {
		if (instance == null) {
			instance = new connection();
		} else if (instance.getConnection().isClosed()) {
			instance = new connection();
		}
		return instance;
	}

	public static void main(String[] args) {
		try {
			Class.forName("");
		} catch (ClassNotFoundException e) {

		
	}
}}
