package Metier;

public class Pharmacie {
//les donnes 
		private String Nom;
		private String Emplacement ;
		
		public Pharmacie( String nom, String Emplacement) {
			super();
			this.Nom = nom;
			this.Emplacement = Emplacement;
		}
		//getter & setter////
		public String getNom() {
			return Nom;
		}

		public void setNom(String nom) {
			Nom = nom;
		}

		public String getEmplacement() {
			return Emplacement;
		}

		public void setEmplacement(String emplacement) {
			Emplacement = emplacement;
		}
		
//tostring
		@Override
		public String toString() {
			return "Pharmacie " + Nom + ", est localiser a " + Emplacement ;
		}
		
		
}
