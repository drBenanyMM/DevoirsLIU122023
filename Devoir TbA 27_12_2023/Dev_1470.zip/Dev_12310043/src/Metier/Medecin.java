package Metier;

public class Medecin {
	private int IdMedecin;
	private String NomMedecin;
	private String PrenomMedecin;
	private String Specialite;
	
	public int getIdMedecin() {
		return IdMedecin;
	}

	public void setIdMedecin(int idMedecin) {
		IdMedecin = idMedecin;
	}

	public String getNomMedecin() {
		return NomMedecin;
	}

	public void setNomMedecin(String nomMedecin) {
		NomMedecin = nomMedecin;
	}

	public String getPrenomMedecin() {
		return PrenomMedecin;
	}

	public void setPrenomMedecin(String prenomMedecin) {
		PrenomMedecin = prenomMedecin;
	}

	public String getSpecialite() {
		return Specialite;
	}

	public void setSpecialite(String specialite) {
		Specialite = specialite;
	}

	public Medecin( int idMedecin, String nomMedecin,String prenomMedecin, String specialite) {
		super();
		this.IdMedecin = idMedecin;
		this.PrenomMedecin = nomMedecin;
		this.PrenomMedecin = prenomMedecin;
		this.Specialite = specialite;
	}

}
