package Metier;

public class Medicament {
	private int Code;
	private String NomMedicament;
	private String Dosage;
	private int Prix;
	private int Stock;
	
	public Medicament(int code, String nomMedicament, String dosage, int prix, int stock) {
		super();
		this.Code = code;
		this.NomMedicament = nomMedicament;
		this.Dosage = dosage;
		this.Prix = prix;
		this.Stock = stock;
	}

	public int getCode() {
		return Code;
	}

	public void setCode(int code) {
		Code = code;
	}

	public String getNomMedicament() {
		return NomMedicament;
	}

	public void setNomMedicament(String nomMedicament) {
		NomMedicament = nomMedicament;
	}

	public String getDosage() {
		return Dosage;
	}

	public void setDosage(String dosage) {
		Dosage = dosage;
	}

	public int getPrix() {
		return Prix;
	}

	public void setPrix(int prix) {
		Prix = prix;
	}

	public int getStock() {
		return Stock;
	}

	public void setStock(int stock) {
		Stock = stock;
	}
	

}
