package Metier;

public class Patient {
	private int IdClient;
	private String NomClient;
	private String PrenomClient;
	private String AdresseClient;
	private int NumClient;
	
	public Patient( int idClient, String nomClient,String prenomClient, String adresseClient, int numClient) {
		super();
		this.IdClient = idClient;
		this.NomClient = nomClient;
		this.PrenomClient = prenomClient;
		this.AdresseClient = adresseClient;
		this.NumClient = numClient;
	}

	

	public int getIdClient() {
		return IdClient;
	}

	public void setIdClient(int idClient) {
		IdClient = idClient;
	}

	public String getNomClient() {
		return NomClient;
	}

	public void setNomClient(String nomClient) {
		NomClient = nomClient;
	}

	public String getPrenomClient() {
		return PrenomClient;
	}

	public void setPrenomClient(String prenomClient) {
		PrenomClient = prenomClient;
	}

	public String getAdresseClient() {
		return AdresseClient;
	}

	public void setAdresseClient(String adresseClient) {
		AdresseClient = adresseClient;
	}

	public int getNumClient() {
		return NumClient;
	}

	public void setNumClient(int numClient) {
		NumClient = numClient;
	}
	
	@Override
	public String toString() {
		return "Patient [IdClient=" + IdClient + ", NomClient=" + NomClient + ", PrenomClient=" + PrenomClient
				+ ", AdresseClient=" + AdresseClient + ", NumClient=" + NumClient + ", getIdClient()=" + getIdClient()
				+ ", getNomClient()=" + getNomClient() + ", getPrenomClient()=" + getPrenomClient()
				+ ", getAdresseClient()=" + getAdresseClient() + ", getNumClient()=" + getNumClient() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
