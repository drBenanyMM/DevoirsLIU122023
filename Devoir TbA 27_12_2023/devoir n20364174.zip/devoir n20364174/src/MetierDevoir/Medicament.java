package MetierDevoir;

public class Medicament {
	private int  codeM  ;
	private String nomMe;
	private String prenomMe ;
	private String prixM;
	private String nomPH;
	private String idPH;
	public Medicament(int codeM, String nomMe, String prenomMe, String prixM, String nomPH, String idPH) {
		super();
		this.codeM = codeM;
		this.nomMe = nomMe;
		this.prenomMe = prenomMe;
		this.prixM = prixM;
		this.nomPH = nomPH;
		this.idPH = idPH;
	}
	public int getCodeM() {
		return codeM;
	}
	public void setCodeM(int codeM) {
		this.codeM = codeM;
	}
	public String getNomMe() {
		return nomMe;
	}
	public void setNomMe(String nomMe) {
		this.nomMe = nomMe;
	}
	public String getPrenomMe() {
		return prenomMe;
	}
	public void setPrenomMe(String prenomMe) {
		this.prenomMe = prenomMe;
	}
	public String getPrixM() {
		return prixM;
	}
	public void setPrixM(String prixM) {
		this.prixM = prixM;
	}
	public String getNomPH() {
		return nomPH;
	}
	public void setNomPH(String nomPH) {
		this.nomPH = nomPH;
	}
	public String getIdPH() {
		return idPH;
	}
	public void setIdPH(String idPH) {
		this.idPH = idPH;
	}
	@Override
	public String toString() {
		return "Medicament [codeM=" + codeM + ", nomMe=" + nomMe + ", prenomMe=" + prenomMe + ", prixM=" + prixM
				+ ", nomPH=" + nomPH + ", idPH=" + idPH + "]";
	}
	
	
}
