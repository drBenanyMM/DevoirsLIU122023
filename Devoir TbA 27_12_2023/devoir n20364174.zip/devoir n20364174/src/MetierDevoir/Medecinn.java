package MetierDevoir;

public class Medecinn {
	private int  idMed  ;
	private String nomMed;
	private String prenomMed ;
	public Medecinn(int nNI, String nom, String prenom) {
		super();
		idMed = idMed;
		this.nomMed = nomMed;
		this.prenomMed = prenomMed;
	}
	public int getIdMed() {
		return idMed;
	}
	public void setIdMed(int idMed) {
		this.idMed = idMed;
	}
	public String getNomMed() {
		return nomMed;
	}
	public void setNomMed(String nomMed) {
		this.nomMed = nomMed;
	}
	public String getPrenomMed() {
		return prenomMed;
	}
	public void setPrenomMed(String prenomMed) {
		this.prenomMed = prenomMed;
	}
	@Override
	public String toString() {
		return "Medecinn [idMed=" + idMed + ", nomMed=" + nomMed + ", prenomMed=" + prenomMed + "]";
	}
	
}
	
	