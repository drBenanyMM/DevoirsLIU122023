package MetierDevoir;

public class pharmacie {
	 private int nomPH;
	private String emplacement;
	public pharmacie(int nomPH, String emplacement) {
		super();
		this.nomPH = nomPH;
		this.emplacement = emplacement;
	}
	public int getNomPH() {
		return nomPH;
	}
	public void setNomPH(int nomPH) {
		this.nomPH = nomPH;
	}
	public String getEmplacement() {
		return emplacement;
	}
	public void setEmplacement(String emplacement) {
		this.emplacement = emplacement;
	}
	@Override
	public String toString() {
		return "pharmacie [nomPH=" + nomPH + ", emplacement=" + emplacement + "]";
	}
	

}
