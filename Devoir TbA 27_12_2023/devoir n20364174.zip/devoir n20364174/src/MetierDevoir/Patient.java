package MetierDevoir;

public class Patient {
	private int idP;
	private String nomP;
	private String prenomP ;
	public Patient(int idP, String nomP, String prenomP) {
		super();
		this.idP = idP;
		this.nomP = nomP;
		this.prenomP = prenomP;
	}
	public int getIdP() {
		return idP;
	}
	public void setIdP(int idP) {
		this.idP = idP;
	}
	public String getNomP() {
		return nomP;
	}
	public void setNomP(String nomP) {
		this.nomP = nomP;
	}
	public String getPrenomP() {
		return prenomP;
	}
	public void setPrenomP(String prenomP) {
		this.prenomP = prenomP;
	}
	@Override
	public String toString() {
		return "Patient [idP=" + idP + ", nomP=" + nomP + ", prenomP=" + prenomP + "]";
	}
	
}
