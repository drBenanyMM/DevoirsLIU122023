package MetierDevoir;

public class vente {
	private int numTR;
	private String datee;
	private String montant ;
	public vente(int numTR, String datee, String montant) {
		super();
		this.numTR = numTR;
		this.datee = datee;
		this.montant = montant;
	}
	public int getNumTR() {
		return numTR;
	}
	public void setNumTR(int numTR) {
		this.numTR = numTR;
	}
	public String getDatee() {
		return datee;
	}
	public void setDatee(String datee) {
		this.datee = datee;
	}
	public String getMontant() {
		return montant;
	}
	public void setMontant(String montant) {
		this.montant = montant;
	}
	@Override
	public String toString() {
		return "vente [numTR=" + numTR + ", datee=" + datee + ", montant=" + montant + "]";
	}
	
}
