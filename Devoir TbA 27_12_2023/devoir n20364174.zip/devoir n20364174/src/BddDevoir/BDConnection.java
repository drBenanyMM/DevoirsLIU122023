package BddDevoir;
import java.sql.*;
import java.sql.Connection;

import BddDevoir.BDConnection;
public class BDConnection {
	private static Connection connection;
	private static BDConnection Instance;
	private static String url="jdbc:mysql://localhost:3306/";
	private static String user="root";
	private static String motdepasse="";
	private static String bdd="devoirbdd";
	public BDConnection() throws SQLException{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.connection=DriverManager.getConnection(url,user,motdepasse);
			System.out.println("connectin etabie a la  base de donne "+bdd);
		    System.out.println();}
		 catch (ClassNotFoundException  e) {
			 
			 System.out.println("erreur du driver "+e.getMessage() );
		} catch (Exception e) {
			System.out.println("erreur SQl "+e.getMessage() );}}
	public Connection getConnection() {
		return connection;}
	public static BDConnection getInstance() throws SQLException {
		if (Instance == null) {
			Instance = new BDConnection();
		} else if (Instance.getConnection().isClosed()) {
			Instance = new BDConnection();
		}
		return Instance;
	}
		
		public void main (String[]a) throws SQLException {
			BDConnection.getInstance().getConnection();
		}
	}