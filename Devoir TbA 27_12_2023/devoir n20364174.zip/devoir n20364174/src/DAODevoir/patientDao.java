package DAODevoir;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import BddDevoir.BDConnection;
import MetierDevoir.Medecinn;

public class patientDao  {
	public static void main(String[] args) throws SQLException {
		BDConnection.getInstance().getConnection();
		;
		
		try {
			
			
			Connection connexion =null;
			Statement st=connexion.createStatement();
			ResultSet rs=st.executeQuery("select * from patient");
			//String 
			String req="insert into patient(idP,nomP,prenomP) values (?,?,?)";
			PreparedStatement st1=connexion.prepareStatement(req);
			st1.setInt(1, 6797);
			st1.setString(2, "fatima");
			st1.setString(3, "cisse");
			  int r = st1.executeUpdate();
			while(rs.next()) {  
				
			
				System.out.println(rs.getString("nomP"));
				
				
			}
			
			
			
		
		}
		catch(SQLException e) {
			System.out.println("Erreur SQL");
		}
		
	}
}
