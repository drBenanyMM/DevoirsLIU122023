package DAODevoir;

public class venteDao {

}
