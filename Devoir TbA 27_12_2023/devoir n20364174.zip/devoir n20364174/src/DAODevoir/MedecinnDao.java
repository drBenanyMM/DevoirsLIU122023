package DAODevoir;
import java.sql.*;
import java.util.List;

import BddDevoir.BDConnection;
import MetierDevoir.Medecinn;

import java.util.ArrayList;
 
public class MedecinnDao implements DAO<Medecinn>{
 private Connection connection=null;
 public  MedecinnDao() {
	 try {
		 connection=BDConnection.getInstance().getConnection();
	} catch (Exception e) {
		e.printStackTrace();
	}
	 
 }
	//get byId
	public Medecinn get(long id) {
		Medecinn Medecinn =null;
		String requet= "select * from Medecinn where idMed = " +(int) id;
		System.out.println(requet);
		try {
			Statement st=connection.createStatement();
			ResultSet rs=st.executeQuery(requet);
			if (rs.next()) {
				int idMed = rs.getInt("idMed");
				String nomMed = rs.getString("nomMed");
				String prenomMed =  rs.getString("prenomMed");
				Medecinn = new Medecinn(idMed, nomMed,prenomMed);
				System.out.println(Medecinn .toString());
				System.out.println();}
			else  throw new SQLException();
		} catch (Exception e) {
			System.out.println("erreur sql element introuvables");
			e.printStackTrace();
		}
		return Medecinn ;
	}

	@Override
	public List<Medecinn> getAll() {
		Medecinn Medecinn  =null;
		ArrayList<Medecinn> medecins= new ArrayList<>();
		String requet = "SELECT * FROM Medecinn ";
		System.out.println(requet); 
		System.out.println(); 

		try {
			Statement st=connection.createStatement();
			ResultSet rs=st.executeQuery(requet);
			if (rs.next()) {
				int idMed = rs.getInt("idMed");
				String nomMed = rs.getString("nomMed");
				String prenomMed =  rs.getString("prenomMed");
				Medecinn = new Medecinn(idMed, nomMed,prenomMed);
				System.out.println(Medecinn .toString());
				System.out.println();}
			else  throw new SQLException();
		} catch (Exception e) {
			System.out.println("erreur sql element introuvables");
			e.printStackTrace();
		}
		return medecins;
		

	}

	@Override
	public void save(Medecinn t) {
		String requet="insert into Medecinn (idMed, nomMed, prenomMed) values("+t.getIdMed()+",'"+t.getNomMed()+"','"+t.getPrenomMed()+"')";
		System.out.println(requet);
		try {
			Statement st=connection.createStatement();
			int rs= st.executeUpdate(requet);
			if (rs>0) {
				System.out.println("\tmedecin enregistrée!\n");}
				else throw new SQLException();
			
		} catch (Exception e) {
			System.out.println(" erreur Sql ;enregistrement echouées ");
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(Medecinn t, String[] parametre) {
		String requet = "UPDATE Medecinn  SET =" + "nomMed = '" +parametre[0]+ "'" + "where id= " +t.getIdMed()+"'" ;
		System.out.println("requet");
		try {
			Statement st =connection.createStatement();
			int rs =st.executeUpdate(requet);
			if(rs>0) {
				System.out.println("\tMedecinn modifie !\n");}
				else
					throw new SQLException();
			} catch (SQLException e) {
				System.out.println("Erreur SQL... modification echouee");
				e.printStackTrace();
			}
			
		
	}

	@Override
	public void update(Medecinn t) {
		// TODO Auto-generated method stub
		String requet= "DELETE FROM Medecinn where id = '"+t.getIdMed()+"' ";
		System.out.println(requet);
		System.out.println(); 
		try {
			Statement st =connection.createStatement();
            int  rs =st.executeUpdate(requet);
            if (rs>0) {
            	System.out.println("\t Medecinn supprime!\n");
            }else throw new SQLException();
            
		} catch (Exception e) {
		System.out.println(" erreur sql ;;suppression echouée ");
		e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		//test methode select by id 
		System.out.println("Test methode select by id ");
		new MedecinnDao().get(123);
		//test methode insert/////
		new MedecinnDao().save (new Medecinn (342,"fatima","ISSE"));
		//test methode gelALL
	System.out.println("Test methode gettAll ");
		new MedecinnDao().getAll();
	//test methode Upadate 
		System.out.println("Test methode de modification");
		String parametre[] = {"fatima"};
		new MedecinnDao().update(new MedecinnDao().get(2));
		//test methode delte 
      new MedecinnDao().delete(null, parametre);
	}
}
