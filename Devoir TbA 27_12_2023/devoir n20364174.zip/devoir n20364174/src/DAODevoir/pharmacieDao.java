package DAODevoir;

public class pharmacieDao {

}
