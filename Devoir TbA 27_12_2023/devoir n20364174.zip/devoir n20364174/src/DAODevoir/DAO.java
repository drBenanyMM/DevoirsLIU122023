package DAODevoir;
import java.util.*;
public interface DAO<T> {
	public T get (long id);
	public List<T> getAll();
public void save(T  t);
public void delete(T t ,String[]parametre );
public void update(T t);
}