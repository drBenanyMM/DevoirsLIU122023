package devoir.liu.jdbc;

import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.SQLException; 

public class DBConnection { 
	private static DBConnection instance; 
	private Connection connection; 
	private String url = "jdbc:mysql://localhost:3306/"; 
	private String bdd = "devoirbd"; 
	private String username = "root"; 
	private String password = ""; 

	private DBConnection() { 
		try { 
			Class.forName("com.mysql.cj.jdbc.Driver"); 
			this.connection = DriverManager.getConnection(url+bdd, 
					username, password); 
			System.out.println("Connection etablie à la base de donnees : "+bdd); 
		} catch (SQLException e) {
			System.out.println("Something is wrong with the DB connection String : " + e.getMessage()); 
		} catch (ClassNotFoundException e) { 
			System.out.println("Something is wrong with the Driver : " + e.getMessage()); 
		}
	} 

	public Connection getConnection() { 
		return connection; 
	} 

	public static DBConnection getInstance() throws SQLException { 
		if (instance == null) { 
			instance = new DBConnection(); 
		} else if (instance.getConnection().isClosed()) { 
			instance = new DBConnection(); 
		} 
		return instance; 
	}
	
	public static void main(String [] args) {
		try {
			DBConnection.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
