package devoir.liu.metier;

public class Medicament {

	int code;
	String nom;
	int dosage;
	float prix;
	int stock;
	public Medicament(int code, String nom, int dosage, float prix, int stock) {
		super();
		this.code = code;
		this.nom = nom;
		this.dosage = dosage;
		this.prix = prix;
		this.stock = stock;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getDosage() {
		return dosage;
	}
	public void setDosage(int dosage) {
		this.dosage = dosage;
	}
	public float getPrix() {
		return prix;
	}
	public void setPrix(float prix) {
		this.prix = prix;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	@Override
	public String toString() {
		return "Medicament [code=" + code + ", nom=" + nom + ", dosage=" + dosage + ", prix=" + prix + ", stock="
				+ stock + "]";
	}
	
}
