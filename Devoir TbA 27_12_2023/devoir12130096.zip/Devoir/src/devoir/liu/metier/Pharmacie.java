package devoir.liu.metier;

public class Pharmacie {
	
	String nomPharmacie;
	String emplacement;
	public Pharmacie(String nomPharmacie, String emplacement) {
		super();
		this.nomPharmacie = nomPharmacie;
		this.emplacement = emplacement;
	}
	public String getNomPharmacie() {
		return nomPharmacie;
	}
	public void setNomPharmacie(String nomPharmacie) {
		this.nomPharmacie = nomPharmacie;
	}
	public String getEmplacement() {
		return emplacement;
	}
	public void setEmplacement(String emplacement) {
		this.emplacement = emplacement;
	}
	@Override
	public String toString() {
		return "Pharmacie [nomPharmacie=" + nomPharmacie + ", emplacement=" + emplacement + "]";
	}

}
