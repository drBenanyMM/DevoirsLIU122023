package devoir.liu.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import devoir.liu.jdbc.DBConnection;
import devoir.liu.metier.Pharmacie;

public class PharmacieDao implements Dao<Pharmacie> {
	private Connection conn;
	public PharmacieDao() {
		try {
			conn = DBConnection.getInstance().getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public Pharmacie get(long id) {
		return null;
	}
	public Pharmacie get(String id) {
		Pharmacie pharmacie = null;
		String requet = "SELECT * FROM Pharmacie WHERE nomPharmacie = '" + id + "'";
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			ResultSet rs = pstm.executeQuery(requet);
			if (rs.next()) {
				String nomPharmacie = rs.getString("nomPharmacie");
				String emplacement = rs.getString("emplacement");
				pharmacie  = new Pharmacie(nomPharmacie, emplacement);
				System.out.println(pharmacie.toString());
				System.out.println();
			}
			else throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... élément introuvable");
			e.printStackTrace();
		}
		return pharmacie;
	}
	@Override
	public List<Pharmacie> getAll() {
		Pharmacie pharmacie = null;
		ArrayList<Pharmacie> arrayList = new ArrayList<>();
		String requet = "SELECT * FROM Pharmacie";
		System.out.println();
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			ResultSet rs = pstm.executeQuery(requet);
			if (rs.next())
				do {
					String nomPharmacie = rs.getString("nomPharmacie");
					String emplacement = rs.getString("emplacement");
					pharmacie  = new Pharmacie(nomPharmacie, emplacement);
					arrayList.add(pharmacie);
					System.out.println(pharmacie.toString());
				} while (rs.next());
			else throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... éléments introuvables");
			e.printStackTrace();
		}
		return arrayList;
	}
	@Override
	public void save(Pharmacie t) {
		String requet = "INSERT INTO Pharmacie(nomPharmacie, emplacement) VALUES('"+t.getNomPharmacie()+"', '"+t.getEmplacement()+"')";
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			int rs = pstm.executeUpdate(requet);
			if (rs>0)
				System.out.println("\tPharmacie enregistrée !\n");
			else
				throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... enregistrement échoué");
			e.printStackTrace();
		}
	}
	@Override
	public void update(Pharmacie t, String[] params) {
		String requet = "UPDATE Pharmacie SET "
						+ "emplacement='"+params[0]+"' "
						+ "WHERE nomPharmacie = '" + t.getNomPharmacie() + "'";
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			int rs = pstm.executeUpdate(requet);
			if (rs>0)
				System.out.println("\tPharmacie modifiée !\n");
			else throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... modification échouée");
			e.printStackTrace();
		}
	}
	@Override
	public void delete(Pharmacie t) {
		String requet = "DELETE FROM Pharmacie WHERE nomPharmacie = '" + t.getNomPharmacie() + "'";
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			int rs = pstm.executeUpdate(requet);
			if (rs>0)
				System.out.println("\tPharmacie supprimée !\n");
			else throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... suppression échouée");
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		PharmacieDao dao = new PharmacieDao();
//		dao.save(new Pharmacie("EL CHIVA", "Madrid"));;
//		dao.save(new Pharmacie("SALAMA Medoc", "BMD"));
		dao.getAll();
	}
	
}
