package coucheBdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnectionDevoir {
	private static DbConnectionDevoir instance; 
	 private Connection connection; 
	 private String url = "jdbc:mysql://localhost:3306/devoir"; 
	 private String username = "root"; 
	 private String password = ""; 
	 private DbConnectionDevoir() throws SQLException { 
	  try { 
	   Class.forName("com.mysql.cj.jdbc.Driver"); 
	   this.connection = DriverManager.getConnection(url, 
	username, password); 
	   System.out.println("Connection etablie"); 
	  } catch (ClassNotFoundException ex) { 
	   System.out.println("Something is wrong with the DB connection String : " + ex.getMessage()); 
	  } 
	 } 
	 
	 public  Connection getConnection() { 
	  return connection; 
	 } 
	 
	 public static DbConnectionDevoir getInstance() throws SQLException { 
	  if (instance == null) { 
	   instance = new DbConnectionDevoir(); 
	  } else if (instance.getConnection().isClosed()) { 
	   instance = new DbConnectionDevoir(); 
	  } 
	  return instance; 
	 } 
	 
	 

	public static void main(String[]args) throws SQLException{
		DbConnectionDevoir.getInstance();

	}
}
