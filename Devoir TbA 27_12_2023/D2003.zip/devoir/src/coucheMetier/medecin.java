
package coucheMetier;


public class medecin {
    private int id;
    private String prenom ;
    private String nom;
    private String specialite;

    public medecin() {
        super();
    }

    public medecin(int id,String prenom, String nom,String specialite) {
        super();
        this.id = id;
        this.prenom = prenom;
           this.nom = nom;
        this.specialite = specialite;

        
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getprenom() {
        return prenom;
    }

    public void setprenom(String emplacement) {
        this.prenom = emplacement;
    }
public String getspecialite() {
        return specialite;
    }

    public void setspecialite(String specialite) {
        this.specialite = specialite;
    }

    public String toString() {
         return "medecin [id=" + id + ", prenom=" + prenom + ", nom=" + nom + ", specialite=" + specialite + "]";
    }
}
