package coucheMetier;

public class medicament {
    private String code ;
    private String nom ;
    private String dosage;
    private int prix;
    private String stockDispo ;
    

    public medicament() {
        super();
    }

    public medicament(String code,String nom, String dosage,int prix,String stockDispo) {
        super();
        this.code = code;
        this.nom = nom;
        this.dosage = dosage;
        this.prix = prix;
        this.stockDispo = stockDispo;
        
    }
    public String  getcode() {
        return code;
    }

    public void setcode(String code) {
        this.code = code;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getdosage() {
        return dosage;
    }

    public void setdosage(String dosage) {
        this.dosage = dosage;
    }
public int  getprix() {
        return prix;
    }

    public void setprix(int prix) {
        this.prix = prix;
    }
    public String  getstockDispo() {
        return stockDispo;
    }

    public void setstockDispo(String stockDispo) {
        this.stockDispo = stockDispo;
    }
    public String toString() {
         return "medicament [code=" + code + ", nom=" + nom + ", dosage=" + dosage + ", prix=" + prix + ", stockDispo=" + stockDispo+ "]";
    } 
}
