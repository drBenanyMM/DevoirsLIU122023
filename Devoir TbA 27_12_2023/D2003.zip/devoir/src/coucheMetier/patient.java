package coucheMetier;

public class patient {

    private int idP;
    private String nom;
    private String prenom ;
    private String adresse;
    private int numero;

    public patient() {
        super();
    }

    public patient(int idP,String nom, String prenom,String adresse,int numero) {
        super();
        this.idP = idP;
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.numero = numero;
        
    }
    public int getIdP() {
        return idP;
    }

    public void setIdP(int idP) {
        this.idP = idP;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getprenom() {
        return prenom;
    }

    public void setprenom(String emplacement) {
        this.prenom = emplacement;
    }
public String getadresse() {
        return adresse;
    }

    public void setadresse(String adresse) {
        this.adresse = adresse;
    }
    public int getnumero() {
        return numero;
    }

    public void setnumero(int numero) {
        this.numero = numero;
    }
    public String toString() {
         return "patient [idP=" + idP + ", nom=" + nom + ", prenom=" + prenom + ", adresse=" + adresse + ", numero=" + numero + "]";
    }

}
