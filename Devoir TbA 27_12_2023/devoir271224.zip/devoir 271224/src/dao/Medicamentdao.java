package dao;

public class Medicamentdao {

}
