package dao;

public class Medecindao {

}
