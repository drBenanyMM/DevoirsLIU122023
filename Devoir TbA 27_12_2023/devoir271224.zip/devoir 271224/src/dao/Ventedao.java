package dao;

public class Ventedao {

}
