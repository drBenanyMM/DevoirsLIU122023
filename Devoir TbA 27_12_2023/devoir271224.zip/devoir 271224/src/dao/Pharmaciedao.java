package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bdd.Dbconnection;
import metier.Pharmacie;

public class Pharmaciedao implements Dao<Pharmacie> {
	private	Connection connection = null;
	private Statement stmt =null;
	private String requete = null;
	private Pharmacie pharmacie = null;
	
	public Pharmaciedao() {
		try {
			//une connexion a bdd
			connection = Dbconnection.getConnection();
			//un conteneur de requetes
			stmt = connection.createStatement();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	

	
	public Pharmacie get(String id) {
		//requete
		requete = "select * from Pharmacie where nom ="+ id + ";";
		//recuperer resultat
		try {
		ResultSet rs = stmt.executeQuery(requete);
		//stocker result dans model
		rs.next();
		String nom = rs.getString(1);
		String emplacemant = rs.getString(2);
		pharmacie = new Pharmacie(nom,emplacemant);
		//afficher model
		System.out.println(pharmacie.toString());
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return pharmacie;
				
		
	}

	@Override
	public List<Pharmacie> getAll() {
	List<Pharmacie> liste = new ArrayList<Pharmacie>();
	//requete
			requete = "select * from Pharmacie";
			//recuperer resultat
			try {
			ResultSet rs = stmt.executeQuery(requete);
			//stocker result dans model
			while(rs.next());
			String nom = rs.getString(1);
			String emplacemant = rs.getString(2);
			pharmacie = new Pharmacie(nom,emplacemant);
			//ajouter model a liste
			liste.add(pharmacie);
			//afficher model
			System.out.println(pharmacie.toString());
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			return liste;
	}

	@Override
	public void save(Pharmacie t) {
		//requete
		requete = "insert into Pharmacie values(" + t.getNom() +",'"+ t.getEmplacemant() +"');";
		//recuperer le resultat
				try {
					int rs = stmt.executeUpdate(requete);
					if(rs!=0)
						System.out.println("insertion reussie");
					else
						System.out.println("erreur d'insertion");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
	}

	@Override
	public void update(Pharmacie t, String[] params) {
		requete = "update Pharmacie set nom =" + params[0] +"',emplacemant ='"+ params[1] + "'where nom=" +t.getNom()+";";
		//recuperer le resultat
				try {
					int rs = stmt.executeUpdate(requete);
					if(rs!=0)
						System.out.println("modification reussie");
					else
						System.out.println("erreur de modification");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		
		
	}

	@Override
	public void delete(Pharmacie t) {
		requete = "delete from Pharmacie where nom ="+t.getNom();
		//recuperer le resultat
				try {
					int rs = stmt.executeUpdate(requete);
					if(rs!=0)
						System.out.println("suppression reussie");
					else
						System.out.println("erreur de suppression");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
 
		
	}
	public static void main(String[] args) {
		Pharmaciedao phdao = new Pharmaciedao();
		phdao.get("Ememl");
		phdao.getAll();
		phdao.save(new Pharmacie("chivaa","ksar"));
		String[] params={"inaya","TVZ"};
		phdao.update(phdao.get("Emel"),params );
		phdao.getAll();
		phdao.delete(phdao.get("chivaa"));
		phdao.getAll();
	}


	@Override
	public Pharmacie get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
