package bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Dbconnection {
	static String url = "jdbc:mysql://localhost:3306/TestDb";
	static String username = "root";
	static String password = "";
	static Connection connection = null;
	public static Connection getConnection() {
		
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				connection = DriverManager.getConnection(url,username,password);
				System.out.println("connection etablie");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				
			 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			return connection;
	}
			
			//tester la methode de connection
			public static void main(String[] args) throws SQLException{
				Dbconnection.getConnection();
			}
		

}
