package metier;

public class Medicament {
	private String code;
	private String nom;
	private String dosage;
	private String pu;
	private String stockdisp;
	public Medicament(String code, String nom, String dosage, String pu, String stockdisp) {
		super();
		this.code = code;
		this.nom = nom;
		this.dosage = dosage;
		this.pu = pu;
		this.stockdisp = stockdisp;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getDosage() {
		return dosage;
	}
	public void setDosage(String dosage) {
		this.dosage = dosage;
	}
	public String getPu() {
		return pu;
	}
	public void setPu(String pu) {
		this.pu = pu;
	}
	public String getStockdisp() {
		return stockdisp;
	}
	public void setStockdisp(String stockdisp) {
		this.stockdisp = stockdisp;
	}
	@Override
	public String toString() {
		return "Medicament [code=" + code + ", nom=" + nom + ", dosage=" + dosage + ", pu=" + pu + ", stockdisp="
				+ stockdisp + "]";
	}
	
	

}
