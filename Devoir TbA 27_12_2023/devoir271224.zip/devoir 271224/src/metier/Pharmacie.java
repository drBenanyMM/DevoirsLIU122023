package metier;

public class Pharmacie {
	private String nom;
	private String emplacement;
	public Pharmacie(String nom, String emplacement) {
		super();
		this.nom = nom;
		this.emplacement = emplacement;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getEmplacement() {
		return emplacement;
	}
	public void setEmplacement(String emplacement) {
		this.emplacement = emplacement;
	}
	@Override
	public String toString() {
		return "Pharmacie [nom=" + nom + ", emplacement=" + emplacement + "]";
	}
	public String getEmplacemant() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
