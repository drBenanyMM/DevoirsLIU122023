package metier;

public class Patient {
	private String idpat;
	private String nom;
	private String prenom;
	private String adresse;
	private int numtel;
	public Patient(String idpat, String nom, String prenom, String adresse, int numtel) {
		super();
		this.idpat = idpat;
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.numtel = numtel;
	}
	public String getIdpat() {
		return idpat;
	}
	public void setIdpat(String idpat) {
		this.idpat = idpat;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getNumtel() {
		return numtel;
	}
	public void setNumtel(int numtel) {
		this.numtel = numtel;
	}
	@Override
	public String toString() {
		return "Patient [idpat=" + idpat + ", nom=" + nom + ", prenom=" + prenom + ", adresse=" + adresse + ", numtel="
				+ numtel + "]";
	}
	
	

}
