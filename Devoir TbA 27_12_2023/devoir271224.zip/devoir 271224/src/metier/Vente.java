package metier;

import java.sql.Date;

public class Vente {
	private String numtrans;
	private Date date;
	private int monttotal;
	public Vente(String numtrans, Date date, int monttotal) {
		super();
		this.numtrans = numtrans;
		this.date = date;
		this.monttotal = monttotal;
	}
	public String getNumtrans() {
		return numtrans;
	}
	public void setNumtrans(String numtrans) {
		this.numtrans = numtrans;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getMonttotal() {
		return monttotal;
	}
	public void setMonttotal(int monttotal) {
		this.monttotal = monttotal;
	}
	@Override
	public String toString() {
		return "Vente [numtrans=" + numtrans + ", date=" + date + ", monttotal=" + monttotal + "]";
	}
	
	
	
	

}
