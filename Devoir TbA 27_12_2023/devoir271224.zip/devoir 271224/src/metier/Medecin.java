package metier;

public class Medecin {
	private String idmed;
	private String nom;
	private String prenom;
	private String specialite;
	public Medecin(String idmed, String nom, String prenom, String specialite) {
		super();
		this.idmed = idmed;
		this.nom = nom;
		this.prenom = prenom;
		this.specialite = specialite;
	}
	public String getIdmed() {
		return idmed;
	}
	public void setIdmed(String idmed) {
		this.idmed = idmed;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getSpecialite() {
		return specialite;
	}
	public void setSpecialite(String specialite) {
		this.specialite = specialite;
	}
	@Override
	public String toString() {
		return "Medecin [idmed=" + idmed + ", nom=" + nom + ", prenom=" + prenom + ", specialite=" + specialite + "]";
	}
	
	

}
