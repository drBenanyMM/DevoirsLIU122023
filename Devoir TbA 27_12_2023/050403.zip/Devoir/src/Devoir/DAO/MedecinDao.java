package Devoir.DAO;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import Bdd.Dbconnection;
import Metier.DAO.Medecin;



public class MedecinDao implements DAO<Medecin> {
	
		
	    private Connection connection = null;
	    
	 
	     private Statement state = null;
	     private Medecin medecin = null;
	     private String requette = null;
	     
	     public MedecinDao() {
		      try {
		    	connection = Dbconnection.getConnection();
				state =  connection.createStatement();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		     }

		@Override
		public Medecin get(long id) {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public List<Medecin> getAll() {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public void save(Medecin t) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void update(Medecin t, String[] params) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void delete(Medecin t) {
			// TODO Auto-generated method stub
			
		}
	     }
	     