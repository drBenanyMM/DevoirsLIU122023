package Devoir.DAO;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import Bdd.Dbconnection;
import Metier.DAO.Patient;
import Metier.DAO.Pharmacie;
public class PharmacieDao implements DAO<Pharmacie> {
 private Connection connection = null;
	    
	 
     private Statement state = null;
     private Pharmacie pharmacie = null;
     private String requette = null;
     
     public PharmacieDao() {
	      try {
	    	connection = Dbconnection.getConnection();
			state =  connection.createStatement();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	     }
@Override
public Pharmacie get(long id) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Pharmacie> getAll() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void save(Pharmacie t) {
	// TODO Auto-generated method stub
	
}

@Override
public void update(Pharmacie t, String[] params) {
	// TODO Auto-generated method stub
	
}

@Override
public void delete(Pharmacie t) {
	// TODO Auto-generated method stub
	
}
}
