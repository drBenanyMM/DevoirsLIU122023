package Devoir.DAO;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import Bdd.Dbconnection;
import Metier.DAO.Vente;
public class VenteDao implements DAO<Vente> {
 private Connection connection = null;
	    
	 
     private Statement state = null;
     private Vente vente = null;
     private String requette = null;
     
     public VenteDao() {
	      try {
	    	connection = Dbconnection.getConnection();
			state =  connection.createStatement();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	     }
@Override
public Vente get(long id) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Vente> getAll() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void save(Vente t) {
	// TODO Auto-generated method stub
	
}

@Override
public void update(Vente t, String[] params) {
	// TODO Auto-generated method stub
	
}

@Override
public void delete(Vente t) {
	// TODO Auto-generated method stub
	
}
}
