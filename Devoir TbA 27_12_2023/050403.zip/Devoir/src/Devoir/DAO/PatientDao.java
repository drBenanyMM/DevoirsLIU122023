package Devoir.DAO;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import Bdd.Dbconnection;
import Metier.DAO.Medicament;
import Metier.DAO.Patient;
public class PatientDao implements DAO<Medicament> {

	 private Connection connection = null;
	    
	 
     private Statement state = null;
     private Patient patient = null;
     private String requette = null;
     
     public PatientDao() {
	      try {
	    	connection = Dbconnection.getConnection();
			state =  connection.createStatement();
			//affieche erreur sql
		} catch (SQLException e) {
			e.printStackTrace();
		}
	     }
@Override
public Medicament get(long id) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Medicament> getAll() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void save(Medicament t) {
	// TODO Auto-generated method stub
	
}

@Override
public void update(Medicament t, String[] params) {
	// TODO Auto-generated method stub
	
}

@Override
public void delete(Medicament t) {
	// TODO Auto-generated method stub
	
}
}