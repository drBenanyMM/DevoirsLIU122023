package Metier.DAO;

public class Pharmacie {
	private String Nom;
	private String Emplacement;
	public Pharmacie(String nom, String emplacement) {
		super();
		Nom = nom;
		Emplacement = emplacement;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getEmplacement() {
		return Emplacement;
	}
	public void setEmplacement(String emplacement) {
		Emplacement = emplacement;
	}
	@Override
	public String toString() {
		return "Pharmacie [Nom=" + Nom + ", Emplacement=" + Emplacement + "]";
	}
	

}
