package Metier.DAO;

public class Medecin {
private int Idm;
private String Nom;
private String Prenom;
private String Specialite;
public Medecin() {}
public Medecin (int Idm,String Nom,String Prenom,String Specialite) {
	
super();{
this.Idm=Idm;
this.Nom=Nom;
this.Prenom=Prenom;
this.Specialite=Specialite;
	// TODO Auto-generated constructor stub}
}

}
public int getIdm() {
	return Idm;
}
public void setIdm(int idm) {
	Idm = idm;
}
public String getNom() {
	return Nom;
}
public void setNom(String nom) {
	Nom = nom;
}
public String getPrenom() {
	return Prenom;
}
public void setPrenom(String prenom) {
	Prenom = prenom;
}
public String getSpecialite() {
	return Specialite;
}
public void setSpecialite(String specialite) {
	Specialite = specialite;
}
@Override
public String toString() {
	return "Medecin [Idm=" + Idm + ", Nom=" + Nom + ", Prenom=" + Prenom + ", Specialite=" + Specialite + "]";
}

}