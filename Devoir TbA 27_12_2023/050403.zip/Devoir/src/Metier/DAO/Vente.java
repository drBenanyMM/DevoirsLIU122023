package Metier.DAO;

public class Vente {
	private int NumeroTrans;
	private int Date;
	private int Montant;
	public Vente(int numeroTrans, int date, int montant) {
		super();
		NumeroTrans = numeroTrans;
		Date = date;
		Montant = montant;
	}
	public int getNumeroTrans() {
		return NumeroTrans;
	}
	public void setNumeroTrans(int numeroTrans) {
		NumeroTrans = numeroTrans;
	}
	public int getDate() {
		return Date;
	}
	public void setDate(int date) {
		Date = date;
	}
	public int getMontant() {
		return Montant;
	}
	public void setMontant(int montant) {
		Montant = montant;
	}
	@Override
	public String toString() {
		return "Vente [NumeroTrans=" + NumeroTrans + ", Date=" + Date + ", Montant=" + Montant + "]";
	}
	

}
