package Metier.DAO;

public class Medicament {
private int Code;
private String Nom;
private String Dosage;
private int Prix;
private int Stock;
public Medicament(int code, String nom, String dosage, int prix, int stock) {
	super();
	Code = code;
	Nom = nom;
	Dosage = dosage;
	Prix = prix;
	Stock = stock;
}
public int getCode() {
	return Code;
}
public void setCode(int code) {
	Code = code;
}
public String getNom() {
	return Nom;
}
public void setNom(String nom) {
	Nom = nom;
}
public String getDosage() {
	return Dosage;
}
public void setDosage(String dosage) {
	Dosage = dosage;
}
public int getPrix() {
	return Prix;
}
@Override
public String toString() {
	return "Medicament [Code=" + Code + ", Nom=" + Nom + ", Dosage=" + Dosage + ", Prix=" + Prix + ", Stock=" + Stock
			+ "]";
}
public void setPrix(int prix) {
	Prix = prix;
}
public int getStock() {
	return Stock;
}
public void setStock(int stock) {
	Stock = stock;
}

}
