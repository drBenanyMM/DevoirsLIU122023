package Metier.DAO;

public class Patient {
	private int Idp;
	private String Nom;
	private String Prenom;
	private String Adresse;
	private int Numero;
	public Patient(int idp, String nom, String prenom, String adresse, int numero) {
		super();
		Idp = idp;
		Nom = nom;
		Prenom = prenom;
		Adresse = adresse;
		Numero = numero;
	}
	public int getIdp() {
		return Idp;
	}
	public void setIdp(int idp) {
		Idp = idp;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	@Override
	public String toString() {
		return "Patient [Idp=" + Idp + ", Nom=" + Nom + ", Prenom=" + Prenom + ", Adresse=" + Adresse + ", Numero="
				+ Numero + "]";
	}
	public String getPrenom() {
		return Prenom;
	}
	public void setPrenom(String prenom) {
		Prenom = prenom;
	}
	public String getAdresse() {
		return Adresse;
	}
	public void setAdresse(String adresse) {
		Adresse = adresse;
	}
	public int getNumero() {
		return Numero;
	}
	public void setNumero(int numero) {
		Numero = numero;
	}

}
