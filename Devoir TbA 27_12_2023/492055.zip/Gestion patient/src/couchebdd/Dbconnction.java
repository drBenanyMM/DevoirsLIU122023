package couchebdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class Dbconnction {
	private static Dbconnction instance;
	private Connection connection;
	private String url = "jdbc:mysql://localhost:3306/gestionpatient";
	private String username = "root";
	private String password = "";

	private Dbconnction() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection etablie");
			System.out.println();
		} catch (ClassNotFoundException e) {
			System.out.println("Erreur du Driver : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Erreur SQL : " + e.getMessage());
		}
	}

	public Connection getConnection() {
		return connection;
	}
 
	public static Dbconnction getInstance() throws SQLException {
		if (instance == null) {
			instance = new Dbconnction();
		} else if (instance.getConnection().isClosed()) {
			instance = new Dbconnction();
		}
		return instance;
	}

	public static void main(String[] args) throws SQLException {
		Dbconnction.getInstance().getConnection();

		// Chargement du Driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
		}

	}
}



