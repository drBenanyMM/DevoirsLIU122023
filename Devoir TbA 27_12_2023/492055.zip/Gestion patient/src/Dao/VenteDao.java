package Dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bdd.liu.projet.DbConnection;
import couche.metier.Vente;
import couchebdd.Dbconnction;
import metier.liu.projet2.Livre;
import projet.liu.dao.Livredao;

public class VenteDao  implements Dao<Vente> {
	// varibles de connection
		private Connection conn;

		// initilisation de variable
		public VenteDao() {
			try {
				conn = Dbconnction.getInstance().getConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

	@Override
	public Vente get(long id) {
		Vente vente = null;
		// requett
		String requet = "SELECT * FROM Livre WHERE Numero = " + (int) id;
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			ResultSet rs = pstm.executeQuery(requet);
			if (rs.next()) {
				int Numero= rs.getInt("Numero");
				String Datev = rs.getString("Datev");
				String Montant = rs.getString("Montant ");
				vente = new Vente (Numero, Datev, Montant );
				System.out.println(vente.toString());
				System.out.println();
			} else
				throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... element introuvable");
			e.printStackTrace();
		}
		return vente;
	}

				

	@Override
	public List<Vente> getAll() {
		Vente vente = null;
		ArrayList<Vente> arrayList = new ArrayList<>();
		String requet = "SELECT * FROM Vente";
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			ResultSet rs = pstm.executeQuery(requet);
			if (rs.next())
				do {
					int Numero = rs.getInt("Numero ");
					String Datev = rs.getString("Datev");
					String Montant = rs.getString("Montant");
					vente = new Vente(Numero, Datev, Montant);
					arrayList.add(vente);
					System.out.println(vente.toString());
				} while (rs.next());
			else
				throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... elements introuvables");
			e.printStackTrace();
		}
		return arrayList;
	}

	@Override
	public void save(Vente t) {
		String requet = "INSERT INTO Livre(Numero, Datev, Montant) VALUES(" + t.getNumero() + ", '" + t.getDatev() + "', '"
				+ t.getMontant() + "')";
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			int rs = pstm.executeUpdate(requet);
			if (rs > 0)
				System.out.println("\tLivre enregistre !\n");
			else
				throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... enregistrement echoue");
			e.printStackTrace();
		}

	}

	@Override
	public void update(Vente t, String[] params) {
		String requet = "UPDATE Vente SET titre='" + params[0] + "', " + "Numero=" + Integer.parseInt(params[1]) + " "
				+ "WHERE Numero = " + (int) t.getNumero();
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			int rs = pstm.executeUpdate(requet);
			if (rs > 0)
				System.out.println("\tVente modifie !\n");
			else
				throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... modification echouee");
			e.printStackTrace();
		}

	}

	@Override
	public void delete(Vente t) {
		String requet = "DELETE FROM Livre WHERE Numero = " + (int) t.getNumero();
		System.out.println(requet);
		try {
			Statement pstm = conn.createStatement();
			int rs = pstm.executeUpdate(requet);
			if (rs > 0)
				System.out.println("\tVente supprime !\n");
			else
				throw new SQLException();
		} catch (SQLException e) {
			System.out.println("Erreur SQL... suppression echouee");
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		VenteDao VDao = new VenteDao();
		Vente v12 = new Vente(12 , "p12","0123");
		VDao.save(v12);
}
}
	