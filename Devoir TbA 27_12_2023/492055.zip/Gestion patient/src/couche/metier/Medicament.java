package couche.metier;

public class Medicament {
	private int code;
	private String nom;
	private String Dosage;
	private int prixp;
	private String StockD;
	public Medicament(int code, String nom, String dosage, int prixp, String stockD) {
		super();
		this.code = code;
		this.nom = nom;
		Dosage = dosage;
		this.prixp = prixp;
		StockD = stockD;
	}
	@Override
	public String toString() {
		return "Medicament [code=" + code + ", nom=" + nom + ", Dosage=" + Dosage + ", prixp=" + prixp + ", StockD="
				+ StockD + "]";
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getDosage() {
		return Dosage;
	}
	public void setDosage(String dosage) {
		Dosage = dosage;
	}
	public int getPrixp() {
		return prixp;
	}
	public void setPrixp(int prixp) {
		this.prixp = prixp;
	}
	public String getStockD() {
		return StockD;
	}
	public void setStockD(String stockD) {
		StockD = stockD;
	}
}
