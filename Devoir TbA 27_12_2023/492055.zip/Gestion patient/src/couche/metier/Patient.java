package couche.metier;

public class Patient {
	private int ID;
	private String Nom;
	private String Prenom;
	private String Adress;
	private String Numerotel;
	public Patient(int iD, String nom, String prenom, String adress, String numerotel) {
		super();
		ID = iD;
		Nom = nom;
		Prenom = prenom;
		Adress = adress;
		Numerotel = numerotel;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getPrenom() {
		return Prenom;
	}
	public void setPrenom(String prenom) {
		Prenom = prenom;
	}
	public String getAdress() {
		return Adress;
	}
	public void setAdress(String adress) {
		Adress = adress;
	}
	public String getNumerotel() {
		return Numerotel;
	}
	public void setNumerotel(String numerotel) {
		Numerotel = numerotel;
	}
	@Override
	public String toString() {
		return "Patient [ID=" + ID + ", Nom=" + Nom + ", Prenom=" + Prenom + ", Adress=" + Adress + ", Numerotel="
				+ Numerotel + ", getID()=" + getID() + ", getNom()=" + getNom() + ", getPrenom()=" + getPrenom()
				+ ", getAdress()=" + getAdress() + ", getNumerotel()=" + getNumerotel() + "]";
	}
	

}
