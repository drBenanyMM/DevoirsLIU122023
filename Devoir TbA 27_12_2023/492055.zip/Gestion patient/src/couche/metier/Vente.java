package couche.metier;

public class Vente {
	private int Numero;
	@Override
	public String toString() {
		return "Vente [Numero=" + Numero + ", Datev=" + Datev + ", Montant=" + Montant + ", getNumero()=" + getNumero()
				+ "]";
	}
	public int getNumero() {
		return Numero;
	}
	public void setNumero(int numero) {
		Numero = numero;
	}
	public Vente(int numero, String datev, String montant) {
		super();
		Numero = numero;
		Datev = datev;
		Montant = montant;
	}
	private String Datev;
	private String Montant;
	public String getMontant() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getDatev() {
		// TODO Auto-generated method stub
		return null;
	}
	


}
