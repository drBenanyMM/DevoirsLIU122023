package couche.metier;

public class Medecin {
	private int ID;
	private String Nom;
	private String Prenom;
	private String Specialite;
	@Override
	public String toString() {
		return "Medecin [ID=" + ID + ", Nom=" + Nom + ", Prenom=" + Prenom + ", Specialite=" + Specialite + "]";
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getPrenom() {
		return Prenom;
	}
	public void setPrenom(String prenom) {
		Prenom = prenom;
	}
	public String getSpecialite() {
		return Specialite;
	}
	public void setSpecialite(String specialite) {
		Specialite = specialite;
	}
	public Medecin(int iD, String nom, String prenom, String specialite) {
		super();
		ID = iD;
		Nom = nom;
		Prenom = prenom;
		Specialite = specialite;
	}

}
