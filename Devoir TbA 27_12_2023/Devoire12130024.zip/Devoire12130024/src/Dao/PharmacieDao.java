package Dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Bdd.DbConnection;
import metier.Pharmacie;


public class PharmacieDao implements Dao<Pharmacie> {

	// Connection
	private Connection connection = null;
	// Conteneur de requettes
	private Statement statement = null;
	// Requette
	private String requette = null;
	// le model
	private Pharmacie Pharmacie = null;

	// Constructeur pour initialiser la connection et le conteneur de requettes
	public PharmacieDao() {
		try {
			// connection
			connection = DbConnection.getConnection();
			// Conteneur
			statement = connection.createStatement();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	// La methode getByID prend un long comme id, alors que note model department
	// doit prendre un String, donc on doit surcharger cette methode
	@Override
	public Pharmacie getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	// Surcharger la méthode getByID(String nomDep) en changeant le type de l'id
	public Pharmacie getByID(String id) {
		// REquette
		requette = "SELECT * FROM Pharmacie WHERE NomPh = '" + id + "';";

		try {
			// REsultat
			ResultSet resultSet = statement.executeQuery(requette);
			//
			resultSet.next();
			// Creeer l'objet department
			String NomPh = resultSet.getString(1);
			String emplacement = resultSet.getString(2);
			Pharmacie = new Pharmacie(resultSet.getString(1), resultSet.getString(2));

			System.out.println(Pharmacie.toString());
			System.out.println("gtbyid");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return Pharmacie;
	}

	@Override
	public List<Pharmacie> getAll() {
		// REquette
		requette = "SELECT * FROM Pharmacie;";
		// Creer une liste des departments
		List<Pharmacie> Pharmacies = new ArrayList<Pharmacie>();
		try {
			// Executer la requette
			ResultSet resultSet = statement.executeQuery(requette);

			while (resultSet.next()) {
				// Creer un objet de Pharmacie
				Pharmacie = new Pharmacie(resultSet.getString(1), resultSet.getString(2));
				// Afficher le departmnt recupeté
				System.out.println(Pharmacie.toString());
				// Ajouter cette instance à la liste des departments.
				Pharmacies.add(Pharmacie);
				System.out.println("gtall");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// select all doit retourner la liste de departments
		return Pharmacies;
	}

	@Override
	public void save(Pharmacie t) {
		// REquette
		requette = "INSERT INTO Pharmacie	VALUES ('" + t.getNomPh() + "','" + t.getEmplacement () + "');";
		try {
			// Executer la requette
			int resultat = statement.executeUpdate(requette);
			if (resultat != 0) {
				System.out.println("Insertion du department (" + t.getNomPh() + " , " + t.getEmplacement ()
						+ ") est effectuée.");
			} else {
				System.out.println("ERREIR d'Insertion");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void update(Pharmacie t, String[] args) {
		// REquette
		requette = "UPDATE Pharmacie SET NomPh = '" + args[0] + "', Emplacement ='" + args[1]
				+ "' WHERE NomPh='" + t.getNomPh() + "';";

		System.out.println("On Update department (" + t.getNomPh() + " , " + t.getEmplacement () + ").");
		try {
			// Executer la requette
			int resultat = statement.executeUpdate(requette);
			if (resultat != 0) {
				System.out.println("Apres Update department (" + args[0] + " , " + args[1] + ").");
			} else {
				System.out.println("ERREIR Update");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void delete(Pharmacie t) {
		// REquette
		requette = "DELETE FROM Pharmacie WHERE NomPh='" + t.getNomPh() + "';";
		System.out.println("On supprime ce Pharmacie (" + t.getNomPh() + " , " + t.getEmplacement () + ").");
		try {
			// Executer la requette
			int resultat = statement.executeUpdate(requette);
			if (resultat != 0) {
				System.out.println(
						"Suppression du Pharmacie (" + t.getNomPh() + " , " + t.getEmplacement () + ") est effectué.");
			} else {
				System.out.println("ERREIR De Suppression");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// test
	public static void main(String[] args) {
	    // Create an instance of PharmacieDao
	    PharmacieDao pharmacieDao = new PharmacieDao();

	    // Test getByID(String id)
	    Pharmacie pharmacieById = pharmacieDao.getByID("SomePharmacyName");
	    if (pharmacieById != null) {
	        System.out.println("Pharmacie by ID: " + pharmacieById.toString());
	    } else {
	        System.out.println("Pharmacie not found by ID.");
	    }

	    // Test getAll()
	    System.out.println("All Pharmacies:");
	    for (Pharmacie pharmacie : pharmacieDao.getAll()) {
	        System.out.println(pharmacie.toString());
	    }

	    // Test save()
	    Pharmacie newPharmacie = new Pharmacie("Aliza", "NKtt");
	    pharmacieDao.save(newPharmacie);
	    System.out.println("New Pharmacie inserted: " + newPharmacie.toString());

	    // Test update()
	    Pharmacie pharmacyToUpdate = pharmacieDao.getByID("Aliza");
	    if (pharmacyToUpdate != null) {
	        pharmacieDao.update(pharmacyToUpdate, new String[]{"Zayed", "Ndb"});
	        System.out.println("Pharmacie updated: " + pharmacyToUpdate.toString());
	    } else {
	        System.out.println("Pharmacie not found for update.");
	    }

	    // Test delete()
	    Pharmacie pharmacyToDelete = pharmacieDao.getByID("Zayed");
	    if (pharmacyToDelete != null) {
	        pharmacieDao.delete(pharmacyToDelete);
	        System.out.println("Pharmacie deleted: " + pharmacyToDelete.toString());
	    } else {
	        System.out.println("Pharmacie not found for deletion.");
	    }
	}

}