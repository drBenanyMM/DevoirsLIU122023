package metier;

public class Patient {
	private int IDpat ;
	private String  Nom ;
	private String   Prenome ;
	private String   Adresse ;
	private int  NumeroTel ;
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Patient(int iDpat, String nom, String prenome, String adresse, int numeroTel) {
		super();
		IDpat = iDpat;
		Nom = nom;
		Prenome = prenome;
		Adresse = adresse;
		NumeroTel = numeroTel;
	}
	public int getIDpat() {
		return IDpat;
	}
	public void setIDpat(int iDpat) {
		IDpat = iDpat;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getPrenome() {
		return Prenome;
	}
	public void setPrenome(String prenome) {
		Prenome = prenome;
	}
	public String getAdresse() {
		return Adresse;
	}
	public void setAdresse(String adresse) {
		Adresse = adresse;
	}
	public int getNumeroTel() {
		return NumeroTel;
	}
	public void setNumeroTel(int numeroTel) {
		NumeroTel = numeroTel;
	}
	@Override
	public String toString() {
		return "Patient [IDpat=" + IDpat + ", Nom=" + Nom + ", Prenome=" + Prenome + ", Adresse=" + Adresse
				+ ", NumeroTel=" + NumeroTel + "]";
	}
	
}
