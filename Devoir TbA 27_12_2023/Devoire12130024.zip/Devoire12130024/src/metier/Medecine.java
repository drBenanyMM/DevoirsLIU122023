package metier;

public class Medecine {
	private int  Dmede;
	private String Nom;
	private String  Prenom ;
	private String Specialite ;
	public Medecine() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Medecine(int dmede, String nom, String prenom, String specialite) {
		super();
		Dmede = dmede;
		Nom = nom;
		Prenom = prenom;
		Specialite = specialite;
	}
	public int getDmede() {
		return Dmede;
	}
	public void setDmede(int dmede) {
		Dmede = dmede;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getPrenom() {
		return Prenom;
	}
	public void setPrenom(String prenom) {
		Prenom = prenom;
	}
	public String getSpecialite() {
		return Specialite;
	}
	public void setSpecialite(String specialite) {
		Specialite = specialite;
	}
	@Override
	public String toString() {
		return "Medecine [Dmede=" + Dmede + ", Nom=" + Nom + ", Prenom=" + Prenom + ", Specialite=" + Specialite + "]";
	}

}
