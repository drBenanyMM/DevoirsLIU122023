package metier;

public class Pharmacie {
	private String NomPh;
	private String  Emplacement ;
	public Pharmacie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Pharmacie(String nomPh, String emplacement) {
		super();
		NomPh = nomPh;
		Emplacement = emplacement;
	}
	public String getNomPh() {
		return NomPh;
	}
	public void setNomPh(String nomPh) {
		NomPh = nomPh;
	}
	public String getEmplacement() {
		return Emplacement;
	}
	public void setEmplacement(String emplacement) {
		Emplacement = emplacement;
	}
	@Override
	public String toString() {
		return "Pharmacie [NomPh=" + NomPh + ", Emplacement=" + Emplacement + "]";
	}

}
