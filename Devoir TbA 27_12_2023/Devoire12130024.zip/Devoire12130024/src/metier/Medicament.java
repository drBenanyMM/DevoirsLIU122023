package metier;

public class Medicament {
	// donnees
	private int  Code;
	private String Nom;
	private String Dosage;
	private double PrixParUnit;
	private int StockDisponible;
	public Medicament() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Medicament(int code, String nom, String dosage, double prixParUnit, int stockDisponible) {
		super();
		Code = code;
		Nom = nom;
		Dosage = dosage;
		PrixParUnit = prixParUnit;
		StockDisponible = stockDisponible;
	}
	public int getCode() {
		return Code;
	}
	public void setCode(int code) {
		Code = code;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getDosage() {
		return Dosage;
	}
	public void setDosage(String dosage) {
		Dosage = dosage;
	}
	public double getPrixParUnit() {
		return PrixParUnit;
	}
	public void setPrixParUnit(double prixParUnit) {
		PrixParUnit = prixParUnit;
	}
	public int getStockDisponible() {
		return StockDisponible;
	}
	public void setStockDisponible(int stockDisponible) {
		StockDisponible = stockDisponible;
	}
	@Override
	public String toString() {
		return "Medicament [Code=" + Code + ", Nom=" + Nom + ", Dosage=" + Dosage + ", PrixParUnit=" + PrixParUnit
				+ ", StockDisponible=" + StockDisponible + "]";
	}
		  


}
