package metier.dao;

public class Medicament {
	
	private int Code;
	private String Nom;
	private int Prix;
	private String stock;
	private int ID;
	public Medicament(int code, String nom, int prix, String stock, int iD) {
		super();
		Code = code;
		Nom = nom;
		Prix = prix;
		this.stock = stock;
		ID = iD;
	}
	public int getCode() {
		return Code;
	}
	public void setCode(int code) {
		Code = code;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public int getPrix() {
		return Prix;
	}
	public void setPrix(int prix) {
		Prix = prix;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	@Override
	public String toString() {
		return "Medicament [Code=" + Code + ", Nom=" + Nom + ", Prix=" + Prix + ", stock=" + stock + ", ID=" + ID + "]";
	}
	
	
	
	

}
