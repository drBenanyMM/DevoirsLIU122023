package dao.devoir;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import dbb.devoir.DbConnection;
import metier.dao.Medicament;






public class MedicamentDao implements Dao<Medicament>{
	
	   //variable de connection
		private Connection connection = null;
		
		    //conteneur de requette
		private Statement Statement = null;
		    //requete
		private String requete;
		    //modele
		private Medicament medicament = null;
		
		private List<Medicament> list;
		
		private String requette;

		
		
		 //initialiser les variables
		public MedicamentDao() {
			
			 
			try {
			    connection = DbConnection.getConnection();
				Statement = connection.createStatement();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

		  @Override
			public Medicament get( long id) {
			  
			//1. requette
				requette = "SELECT * from medicament WHERE idAuteur=" + (int) id+";";
			   
				
				//2.recupere les resultat
				
				try {
					
					ResultSet resultSet = Statement.executeQuery(requette);
				
					//3.Stoker ce resultat dans l'objet auteur
					resultSet.next();    
					
					int Code = resultSet.getInt(1);
					String nom = resultSet.getString(2);
					int Prix = resultSet.getInt(3);
					String stock = resultSet.getString(4);
					int ID = resultSet.getInt(5);
					
					medicament = new Medicament(Code,nom,Prix,stock,ID);
					//4.affichage de l'auteur
				    System.out.println(medicament.toString());
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					
						}
				return medicament;
		  
		  }


		@Override
		public List<Medicament> getAll() {
			
			//1. requette
			requette = "SELECT * from medicament ";
			 System.out.println(requette);
			    List<Medicament> list = new ArrayList<>();
			    Medicament Medicament = null;
			
			//2.recupere les resultat
			
			try {
				
				ResultSet resultSet = Statement.executeQuery(requette);
			
				//3.Stoker ce resultat dans l'objet auteur
				resultSet.next();    
				
				int Code = resultSet.getInt(1);
				String nom = resultSet.getString(2);
				int Prix = resultSet.getInt(3);
				String stock = resultSet.getString(4);
				int ID = resultSet.getInt(5);
				
				medicament = new Medicament(Code,nom,Prix,stock,ID);
			
				list.add(Medicament);
				System.out.println(Medicament.toString());
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
			
		
			
		}

		@Override
		public void save(Medicament k) {
			// REquette
			requette = "INSERT INTO medicament	VALUES ("+k.getCode()+",'"+k.getNom()+"','"+k.getPrix() +"','"+k.getStock() +"','"+ k.getID() + "');";
			try {
				// Executer la requette
				int resultat = Statement.executeUpdate(requette);
				if (resultat != 0) {
					System.out.println("Insertion du auteur"); 

				} else {
					System.out.println("Ereur d'Insertion");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
		}

		@Override
		public void delete(Medicament k) {
			// 1 REquette
			requette = "DELETE FROM auteur Where idAuteur=" + k.getCode() + " ;";
			System.out.println(requette);

			try {
				// 2. Recuperer le resulat
				int resulat = Statement.executeUpdate(requette);

				if (resulat != 0)
					System.out.println("Delete effectu� ");
				else {
					System.out.println("ERREUR de DELETE  ");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}

		@Override
		public void update(Medicament k, String[] args) {
			// 1 REquette
						requette = "update auteur set  Code= " + Integer.parseInt(args[0]) + ", nom= '" +args[1] + "', Prix='"
								+ args[2] + "',Stock='" + args[3] + "',ID='" + args[3] + "' Where idauteur=" + k.getCode() + " ;";
						System.out.println(requette);

						try {
							// 2. Recuperer le resulat
							int resulat = Statement.executeUpdate(requette);

							if (resulat != 0)
								System.out.println("Update effectu� ");
							else {
								System.out.println("ERREUR d'UPDATE  ");
							}
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			
		}
		
		
		
		
		//Test main
		public static void main(String[] args) {
			System.out.println("TEST DE LA METODE getId");
			new MedicamentDao().get(3);

			///get all
			new  MedicamentDao().getAll();

			//save
			//new MedicamentDao().save(new Medicament(15151,"panadol" ));
			
			
			//upade
			System.out.println("TEST DE LA METODE update()");
			String[] newMedicament = {  };
			new  MedicamentDao().update(new  MedicamentDao().get(11), newMedicament);
			
			//Test Delete
			System.out.println("TEST DE LA METODE DLETE()");
			new  MedicamentDao().delete(new  MedicamentDao().get(12));

			

			
		}
		
}

		
