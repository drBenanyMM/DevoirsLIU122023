package bdd.lui.projet2024;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	private static DbConnection instance;
	private Connection connection;
	private  String URL="jdbc:mysql://localhost:3306/gestionentreprise";
	private  String USER = "root";
	private  String PASSWORD = "";

	private DbConnection()  throws SQLException{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			this.connection = DriverManager.getConnection(URL,USER,PASSWORD);
			System.out.println("Connecté");
		} catch (ClassNotFoundException e) {
				System.out.println("Erreur du Driver :"+ e.getMessage());
		} catch (SQLException e) {
				System.out.println("Erreur du SQL :"+ e.getMessage());
		}
	}
		public Connection getConnection(){
		    return connection;}
	public static DbConnection getInstance() throws SQLException{
		if (instance == null) {
			instance = new DbConnection();
		}else if (instance.getConnection().isClosed()) {
			instance = new DbConnection();
			}
		return instance;
	}
	public static void main(String[] args) throws SQLException{
		DbConnection.getInstance().getConnection();
	}

}
