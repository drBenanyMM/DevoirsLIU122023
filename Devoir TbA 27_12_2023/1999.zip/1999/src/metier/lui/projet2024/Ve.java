package metier.lui.projet2024;

public class Ve {

}
