package Metier;

public class medicament {
	 private int code;
	 private String nom;
	 private String dosage;
	 private String prix;
	 private String stock;
	 
	 
	public medicament(int code, String nom, String dosage, String prix, String stock) {
		super();
		this.code = code;
		this.nom = nom;
		this.dosage = dosage;
		this.prix = prix;
		this.stock = stock;
	}


	public medicament() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getCode() {
		return code;
	}


	public void setCode(int code) {
		this.code = code;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getDosage() {
		return dosage;
	}


	public void setDosage(String dosage) {
		this.dosage = dosage;
	}


	public String getPrix() {
		return prix;
	}


	public void setPrix(String prix) {
		this.prix = prix;
	}


	public String getStock() {
		return stock;
	}


	public void setStock(String stock) {
		this.stock = stock;
	}


	@Override
	public String toString() {
		return "medicament [code=" + code + ", nom=" + nom + ", dosage=" + dosage + ", prix=" + prix + ", stock="
				+ stock + "]";
	}
	

	 
	 
}
