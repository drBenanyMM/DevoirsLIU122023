package Metier;

public class vente {
	
	private int numero;
	private int montant;
	
	
	public vente(int numero, int montant) {
		super();
		this.numero = numero;
		this.montant = montant;
	}


	public vente() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getNumero() {
		return numero;
	}


	public void setNumero(int numero) {
		this.numero = numero;
	}


	public int getMontant() {
		return montant;
	}


	public void setMontant(int montant) {
		this.montant = montant;
	}


	@Override
	public String toString() {
		return "vente [numero=" + numero + ", montant=" + montant + "]";
	}
	

	
}
