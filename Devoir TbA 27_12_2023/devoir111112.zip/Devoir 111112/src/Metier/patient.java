package Metier;

public class patient {

	
	private int id;
	private String nom;
	private String prenom;
	private String adresse;
	private int numero ;
	
	public patient(int id, String nom, String prenom, String adresse, int numero) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.numero = numero;
	}

	public patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	@Override
	public String toString() {
		return "patient [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", adresse=" + adresse + ", numero="
				+ numero + "]";
	}
	

 
}
