package Metier;

public class pharmacie {
	
	private String nom;
	private String emplacement;
	
	
	public pharmacie(String nom, String emplacement) {
		super();
		this.nom = nom;
		this.emplacement = emplacement;
	}


	public pharmacie() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getEmplacement() {
		return emplacement;
	}


	public void setEmplacement(String emplacement) {
		this.emplacement = emplacement;
	}


	@Override
	public String toString() {
		return "pharmacie [nom=" + nom + ", emplacement=" + emplacement + "]";
	}
	
	
	
	

}
