package Dao;

	
	import java.util.List;

import Metier.medecin;

	public interface Dao<T> {

		T get(long id);
	    
	    List<T> getAll();
	                                                                                   	    
	    void save(T t);
	                                                                                   	    
	    void update(T t, String[] params);
	                                                                                   	    
	     void delete(T t);

		void save(medecin t);

		void update(medecin t, String[] params);
	}




