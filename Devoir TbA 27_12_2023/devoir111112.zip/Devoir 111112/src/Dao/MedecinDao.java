package Dao;

	import java.sql.Connection;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.ArrayList;
	import java.util.List;
	import BDD.DbConnection;
    import Metier.Medecin;




	public abstract class MedecinDao implements Dao<Medecin> {
		
		private Medecin medecin =null;
	
		private Connection conn;
		public MedecinDao() {
			try {
				conn = DbConnection.getInstance().getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		@Override
		public Medecin get(long id) {
			
			String requet = "SELECT * FROM medecin WHERE id = " + (int) id;
			System.out.println(requet);
			try {
				Statement pstm = conn.createStatement();
				ResultSet rs = pstm.executeQuery(requet);
				if (rs.next()) {
					int id1= rs.getInt("id");
					String nom = rs.getString("nom");
					String prenom = rs.getString("prenom");
					String specialite =rs.getString("specialite");
					medecin = new Medecin(id1, nom, prenom,specialite);
					System.out.println(medecin.toString());
					System.out.println();
				}
				else throw new SQLException();
			} catch (SQLException e) {
				System.out.println("Erreur SQL... �l�ment introuvable");
				e.printStackTrace();
			}
			return medecin;
		}
		@Override
		public List<Medecin> getAll() {
			
			List<Medecin> arrayList = new ArrayList<>();
			String requet = "SELECT * FROM medecin";
			System.out.println(requet);
			try {
				Statement pstm = conn.createStatement();
				ResultSet rs = pstm.executeQuery(requet);
				if (rs.next())
					do {
						int id = rs.getInt("id");
						String nom= rs.getString("nom");
						String prenom = rs.getString("prenom");
						String specialite =rs.getString("specialite");
						medecin = new Medecin(id,nom , prenom ,specialite);
						arrayList.add(medecin);
						System.out.println(medecin.toString());
					} while (rs.next());
				else throw new SQLException();
			} catch (SQLException e) {
				System.out.println("Erreur SQL... �l�ments introuvables");
				e.printStackTrace();
			}
			return arrayList;
		}
		@Override
		public void save(Medecin t) {
			String requet = "INSERT INTO medecin(id, nom, prenom,specialite) VALUES("+t.getId()+", '"+t.getNom()+"', '"+t.getPrenom()+"','"+t.getSpecialite()+";";
			System.out.println(requet);
			try {
				Statement pstm = conn.createStatement();
				int rs = pstm.executeUpdate(requet);
				if (rs>0)
					System.out.println("\t medecin enregistr� !\n");
				else
					throw new SQLException();
			} catch (SQLException e) {
				System.out.println("Erreur SQL... enregistrement �chou�");
				e.printStackTrace();
			}
		}
		@Override
		public void update(Medecin t, String[] params) {
			String requet = "UPDATE medecin SET nom='"+params[0]+"', "
							+ "idr='"+params[1]+"' "
							+ "WHERE prenom= " + (String) t.getPrenom();
			System.out.println(requet);
			try {
				Statement pstm = conn.createStatement();
				int rs = pstm.executeUpdate(requet);
				if (rs>0)
					System.out.println("\tmedecin modifi� !\n");
				else throw new SQLException();
			} catch (SQLException e) {
				System.out.println("Erreur SQL... modification �chou�e");
				e.printStackTrace();
			}
		}
		@Override
		public void delete(Medecin t) {
			String requet = "DELETE FROM medecin WHERE id = " + (int) t.getId();
			System.out.println(requet);
			try {
				Statement pstm = conn.createStatement();
				int rs = pstm.executeUpdate(requet);
				if (rs>0)
					System.out.println("\tmedecin supprim� !\n");
				else throw new SQLException();
			} catch (SQLException e) {
				System.out.println("Erreur SQL... suppression �chou�e");
				e.printStackTrace();
			}
		}

		
		


	public static void main(String [] args) {

	}
	}
	