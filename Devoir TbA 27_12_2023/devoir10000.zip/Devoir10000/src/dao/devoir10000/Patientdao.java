package dao.devoir10000;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import bdd.devoir10000.DbConnection;
import metier.devoir10000.Medicament;
import metier.devoir10000.Patient;


public class Patientdao implements dao<Patient> {

	 private Connection connection = null;
	    
	 
     private Statement state = null;
     private Patient patient = null;
     private String requette = null;
     
     public Patientdao() {
	      try {
	    	connection = DbConnection.getInstance().getConnection();
			state =  connection.createStatement();
			//affieche erreur sql
		} catch (SQLException e) {
			e.printStackTrace();
		}
	     }
@Override
public Patient get(long id) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Patient> getAll() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void save(Patient t) {
	// TODO Auto-generated method stub
	
}

@Override
public void update(Patient t, String[] params) {
	// TODO Auto-generated method stub
	
}
@Override
public void delete(Patient t) {
	// TODO Auto-generated method stub
	
}

}
