package dao.devoir10000;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import bdd.devoir10000.DbConnection;
import metier.devoir10000.Medicament;

;
public class Medicamentdao implements dao<Medicament> {
	
	
    private Connection connection = null;
    
 
     private Statement state = null;
     private Medicamentdao medicament = null;
     private String requette = null;
     
     public Medicamentdao() {
	      try {
	    	connection = DbConnection.getInstance().getConnection();
			state =  connection.createStatement();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	     }
public class Medicamantdao {

}
@Override
public Medicament get(long id) {
	// TODO Auto-generated method stub
	return null;
}
@Override
public List<Medicament> getAll() {
	// TODO Auto-generated method stub
	return null;
}
@Override
public void save(Medicament t) {
	// TODO Auto-generated method stub
	
}
@Override
public void update(Medicament t, String[] params) {
	// TODO Auto-generated method stub
	
}
@Override
public void delete(Medicament t) {
	// TODO Auto-generated method stub
	
}
}
