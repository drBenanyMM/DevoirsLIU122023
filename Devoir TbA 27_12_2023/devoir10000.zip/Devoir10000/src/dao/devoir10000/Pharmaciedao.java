package dao.devoir10000;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import bdd.devoir10000.DbConnection;
import metier.devoir10000.Pharmacie;


public class Pharmaciedao implements dao<Pharmacie> {
 private Connection connection = null;
	    
	 
     private Statement state = null;
     private Pharmacie pharmacie = null;
     private String requette = null;
     
     public Pharmaciedao() {
	      try {
	    	connection = DbConnection.getInstance().getConnection();
			state =  connection.createStatement();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	     }
@Override
public Pharmacie get(long id) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Pharmacie> getAll() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void save(Pharmacie t) {
	// TODO Auto-generated method stub
	
}

@Override
public void update(Pharmacie t, String[] params) {
	// TODO Auto-generated method stub
	
}

@Override
public void delete(Pharmacie t) {
	// TODO Auto-generated method stub
	
}
}