package dao.devoir10000;

import java.util.List;
import java.util.Optional;

import metier.devoir10000.Medecin;

public interface dao<T> { 
       T get(long id);
	    
	    List<T> getAll();
	    
	    void save(T t);
	    
	    void update(T t, String[] params);
	    
        void delete(T t);    

}


