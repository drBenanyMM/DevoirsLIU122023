package dao.devoir10000;


	import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import bdd.devoir10000.DbConnection;
import metier.devoir10000.Vente;

	
	public class Ventedao implements dao<Vente> {
	 private Connection connection = null;
		    
		 
	     private Statement state = null;
	     private Vente vente = null;
	     private String requette = null;
	     
	     public Ventedao() {
		      try {
		    	connection = DbConnection.getInstance().getConnection();
				state =  connection.createStatement();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		     }
	@Override
	public Vente get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Vente> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Vente t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Vente t, String[] params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Vente t) {
		// TODO Auto-generated method stub
		
	}
	}

