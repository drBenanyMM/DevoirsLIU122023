package metier.devoir10000;

import java.sql.Date;

public class Vente {
private int Nvente;
private String Montant;
private Date Dvente;
public Vente() {
	super();
}
public Vente(int nvente, String montant, Date dvente) {
	super();
	Nvente = nvente;
	Montant = montant;
	Dvente = dvente;
}
public int getNvente() {
	return Nvente;
}
public void setNvente(int nvente) {
	Nvente = nvente;
}
public String getMontant() {
	return Montant;
}
public void setMontant(String montant) {
	Montant = montant;
}
public Date getDvente() {
	return Dvente;
}
public void setDvente(Date dvente) {
	Dvente = dvente;
}
@Override
public String toString() {
	return "Vente [Nvente=" + Nvente + ", Montant=" + Montant + ", Dvente=" + Dvente + "]";
}


}
