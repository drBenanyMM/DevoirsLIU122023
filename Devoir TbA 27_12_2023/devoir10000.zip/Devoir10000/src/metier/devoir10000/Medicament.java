package metier.devoir10000;

public class Medicament {
private int code;
private String nom;
private String dosage;
private int prix;
private String stock;
public Medicament() {
	super();
}
public Medicament(int code, String nom, String dosage, int prix, String stock) {
	super();
	this.code = code;
	this.nom = nom;
	this.dosage = dosage;
	this.prix = prix;
	this.stock = stock;
}
public int getCode() {
	return code;
}
public void setCode(int code) {
	this.code = code;
}
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public String getDosage() {
	return dosage;
}
public void setDosage(String dosage) {
	this.dosage = dosage;
}
public int getPrix() {
	return prix;
}
public void setPrix(int prix) {
	this.prix = prix;
}
public String getStock() {
	return stock;
}
public void setStock(String stock) {
	this.stock = stock;
}
@Override
public String toString() {
	return "Medicament [code=" + code + ", nom=" + nom + ", dosage=" + dosage + ", prix=" + prix + ", stock=" + stock
			+ "]";
}

}
