package Services;

import Entities.Result;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@XmlRootElement
public class Employee {
    private String firstName;
    private String lastName;
    private String email;

    // Constructeurs, getters et setters

    @XmlElement(name = "firstName")
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @XmlElement(name = "lastName")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @XmlElement(name = "email")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Méthode pour ajouter un employé à la base de données PostgreSQL
    public Result addEmployeeToDatabase() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Charger le pilote JDBC
            Class.forName("org.postgresql.Driver");

            // Configurer les informations de connexion
            String url = "jdbc:postgresql://localhost:5432/Dev";
            String username = "postgres";
            String password = "Fouda";

            // Établir la connexion à la base de données
            connection = DriverManager.getConnection(url, username, password);

            // Préparer la requête SQL pour ajouter un employé
            String sql = "INSERT INTO employes (prenom, nom, email) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, getFirstName());
            preparedStatement.setString(2, getLastName());
            preparedStatement.setString(3, getEmail());

            // Exécuter la requête
            preparedStatement.executeUpdate();

            return new Result("Employee added successfully");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return new Result("Error adding employee: " + e.getMessage());
        } finally {
            // Fermer les ressources
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
