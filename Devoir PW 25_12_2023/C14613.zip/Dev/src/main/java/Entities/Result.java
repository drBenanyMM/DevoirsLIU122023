package Entities;

public class Result {
    private String message;

    public Result(String message) {
        this.message = message;
    }

}
