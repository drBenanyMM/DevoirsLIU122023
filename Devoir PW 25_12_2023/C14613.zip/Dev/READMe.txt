Devoir (reponse sur les questions) :

1-	SOA signifie "Service-Oriented Architecture". Il s'agit d'un style d'architecture logicielle qui organise
    les services informatiques pour les rendre interopérables et réutilisables.

2-	L'architecture de service web SOAP est le suivant, utilise WSDL pour décrire l'interface abstraite du service web,
    SOAP pour fournir une implémentation concrète avec une structure XML normalisée, et la communication se fait via
    des requêtes et des réponses HTTP (ou d'autres protocoles). L'enveloppe `<Envelope>` et
    le corps `<Body>` sont les éléments essentiels d'un message SOAP, tandis que `<Header>` et `<Fault>` sont facultatifs.

3-	L'appel d'un service web de type SOAP implique les générales suivantes étapes :

-	Création du client ;
-	Création du message SOAP ;
-	Encapsulation du message dans une requête HTTP ;
-	Envoi de la requête au service ;
-	Réception de la requête par le service ;
-	Traitement de la requête par le service ;
-	Création de la réponse SOAP ;
-	Encapsulation de la réponse dans une réponse HTTP ;
-	Réception de la réponse par le client ;
-	Traitement de la réponse par le client.

4- les avantags d'utiliser un service web SOAP sont :
   - Interopérabilité ;
   - Standardisation ;
   - Sécurité ;
   - Gestion des erreurs ;
   - Compatibilité avec d'autres protocoles de transport.