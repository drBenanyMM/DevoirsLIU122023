package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.DbConnection;
import model.Employer;





public class EmployerDao implements Dao<Employer> {
	Connection connection = null;
	Statement statement = null;
	String requet = null;
    Employer employer = null;
	
	public EmployerDao() {
		try {
			connection = DbConnection.getInstance().getConnection();
			statement = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public List<Employer> getAll() {
        List<Employer> employer = new ArrayList<>();
        requet = "SELECT * FROM personne";
       // System.out.println(requet);

        try {
            ResultSet resultSet = statement.executeQuery(requet);
            while (resultSet.next()) {
                int nni = resultSet.getInt("nni");
                String nom = resultSet.getString("nom");
                employer = (List<Employer>) new Employer(nni, nom);
                employer.addAll(employer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return employer;
    }

	@Override
	public Employer getById(int id) {
		// TODO Auto-generated method stub
		requet = "SELECT * FROM personne WHERE nni =" + id + " ;";
	    try (ResultSet resultSet = statement.executeQuery(requet)) {
	        if (resultSet.next()) {
	            int nni = resultSet.getInt("nni");
	            String nom = resultSet.getString("nom");
	       employer = new Employer(nni, nom);
	            System.out.println(employer.toString());
	        } else {
	            System.out.println("L'id " + id + " n'existe pas.");
	           // or throw an exception, depending on your design
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        // Handle the exception, e.g., log it or throw a custom exception
	    }

	    return employer;
	}

	public void save(Employer E) {
		// TODO Auto-generated method stub
		requet = "insert into personne values(" + E.getNni() + ",'" + E.getNom() + "');";
		System.out.println(requet);

		try {
			int resultat = statement.executeUpdate(requet);
			if (resultat != 0) {
				System.out.println("Insertion effectuée");
			} else {
				System.out.println("Erreur d'insertion");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	public void update(Employer updatedPersonne) {
        // Assuming updatedPersonne contains the new values to be updated.
        requet = "UPDATE PERSONNE SET nom = '" + updatedPersonne.getNom() + "' WHERE nni = " + updatedPersonne.getNni() + ";";
      //  System.out.println(requet);

        try {
            int resultat = statement.executeUpdate(requet);
            if (resultat != 0) {
                System.out.println("Mise à jour effectuée");
            } else {
                System.out.println("Erreur de mise à jour");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
	 public void delete(Employer t) {
	        requet = "DELETE FROM PERSONNE WHERE nni = " + t.getNni() + ";";
	      //  System.out.println(requet);

	        try {
	            int resultat = statement.executeUpdate(requet);
	            if (resultat != 0) {
	                System.out.println("Suppression effectuée");
	            } else {
	                System.out.println("Erreur de suppression");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	@Override
	public void update(Employer t, int[] params) {
		// TODO Auto-generated method stub
		
	}

	
//	public void delete(Object t) {
//		// TODO Auto-generated method stub
//		
//	}


}
