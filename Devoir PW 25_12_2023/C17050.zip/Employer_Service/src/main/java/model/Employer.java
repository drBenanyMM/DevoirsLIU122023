package model;

public class Employer  {
	private int nni;
	private String nom;
	
	
	public Employer(int nni, String nom) {
		super();
		this.nni = nni;
		this.nom = nom;
	}


	public Employer() {
		super();
	}


	public int getNni() {
		return nni;
	}


	public void setNni(int nni) {
		this.nni = nni;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}
	
	
}
