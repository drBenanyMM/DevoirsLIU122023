
 package service;
import dao.EmployerDao;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import model.Employer;

import service.ServiceOperation;

@WebService(endpointInterface = "service.ServiceOperation")
public class ServiceOperationImp implements ServiceOperation{
EmployerDao dao=new EmployerDao();
    public int addition(@WebParam(name = "a") int a, @WebParam(name = "b") int b) {
        return a + b;
    }
	@Override
	public Employer getEmployerById(@WebParam(name = "nni") int nni) {
		// TODO Auto-generated method stub
		return dao.getById(nni);
	}
	@Override
	public void saveEmployer(Employer employer) {
		// TODO Auto-generated method stub
		dao.save(employer);
	}
	@Override
	public void updateEmployer(Employer employer) {
		// TODO Auto-generated method stub
		dao.update(employer);
	}
	@Override
	public void deleteEmployer(int nni) {
		// TODO Auto-generated method stub
		Employer employerToDelete = dao.getById(nni);
        if ( employerToDelete != null) {
            dao.delete( employerToDelete);
        } else {
            System.out.println("Personne with NNI " + nni + " not found.");
        }
    }
		
	}
   

	

	
	
    
	
	
