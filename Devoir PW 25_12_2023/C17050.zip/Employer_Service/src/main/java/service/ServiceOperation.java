package service;

import dao.EmployerDao;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import model.Employer;
;

@WebService(name = "service d'addition")
public interface ServiceOperation {
    @WebMethod(operationName="addition")    
    public int addition(@WebParam(name = "a") int a, @WebParam(name = "b") int b) ;
    //===Methode read=======
    public Employer getEmployerById(@WebParam(name = "nni") int nni);
    public void saveEmployer(@WebParam(name = "Employer") Employer personne);
    public void updateEmployer(@WebParam(name = "p") Employer personne);
    public void deleteEmployer(@WebParam(name = "n") int nni);
	
}

