package Dao;

import java.util.List;

public interface Dao<Employer> {
	    
	    
	    List<Employer>getAll();
	    Employer getById(int Id);
	    void save(Employer  em);
	    void update(Employer em );
	    void delete(Employer em);
	    
	   
	} 

	
	

