package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import Modele.Employer;
import db.DbConnection;
import jakarta.jws.WebParam;

public class EmployerDao implements Dao<Employer> {

	
	Connection connection = null;
	Statement statement = null;
	String requet = null;
	Employer em = null;

	public EmployerDao() {
		try {
			connection = DbConnection.getInstance().getConnection();
			statement = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
	public List<Employer> getAll() {
		return null;
	}

	public Employer getById(int Id) {
		requet = "SELECT * FROM EMPLOYER WHERE id=" + Id + ";";
				System.out.println(requet);
		try {
			ResultSet resultSet = statement.executeQuery(requet);
			resultSet.next();
			int id = resultSet.getInt(1);
			String nom = resultSet.getString("awa");
			String prenom = resultSet.getString("fall");
			String metier = resultSet.getString("developeuse");

			Employer  em= new Employer(id, nom,prenom,metier);
			System.out.println(em.toString());

		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return em;
	}

	

	public void save(@WebParam(name = "em") Employer em ) {
		requet = "insert into employer values(" + em.getId() + ",'" + em.getNom() 
		+ ",'" +em.getPrenom()+ ",'" +em.getMetier() + "');";
		System.out.println(requet);

		try {
			int resultat = statement.executeUpdate(requet);
			if (resultat != 0) {
				System.out.println("Insertion reussi");
			} else {
				System.out.println("Erreur d'insertion");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void update(Employer em) {
		
		 String query = "UPDATE EMPLOYER SET nom = ? WHERE id = ?;";
		 try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            preparedStatement.setInt(1, em.getId());
	            preparedStatement.setString(2, em.getNom());
	            preparedStatement.setString(3, em.getPrenom());
	            preparedStatement.setString(4, em.getMetier());


	            preparedStatement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
		
	}

	public void delete(Employer em) {
		  String query = "DELETE FROM EMPLOYER WHERE id = ?;";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            preparedStatement.setInt(1, em.getId());

	            preparedStatement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
		
	}
//	public static void main(String []args) {
//		System.out.println(new EmployerDao().getById(2));
//
//	}
	

}
