package service;

import java.util.List;

import Modele.Employer;
import jakarta.jws.WebService;

@WebService
public interface EmployerService {

	void addEmployer(Employer em);
    
		Employer getById(int Id);
	    List<Employer>getAll();
	
	    void update(Employer em );
	    void delete(Employer em); 
	
	
	
}
