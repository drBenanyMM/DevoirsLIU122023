package service;

import java.util.List;

import Dao.EmployerDao;
import Modele.Employer;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;

@WebService(endpointInterface = "service.EmployerService")

public class EmployerServiceImp implements EmployerService{

	
    private  EmployerDao emDao = new EmployerDao ();

	@Override
    @WebMethod(operationName = "SaveEmployer")

	public void addEmployer(Employer em) {
		
		        emDao.save(em);

		
	}

	@Override
    @WebMethod(operationName = "GetEmployerById")

	public Employer getById(int Id) {
		
		return emDao.getById(Id);
	}

	@Override
    @WebMethod(operationName = "GetAllEmployers")

	public List<Employer> getAll() {
		return emDao.getAll();
	}


	@Override
    @WebMethod(operationName = "UpdateEmployer")

	public void update(Employer em) {
		 emDao.update(em);
		
	}

	@Override
    @WebMethod(operationName = "DeleteEmployer")

	public void delete(Employer em) {
		emDao.delete(em);
		
	}

}
