package service;
 	

import jakarta.xml.ws.Endpoint;




public class EmployerServicePublisher {
    public static void main(String[] args) {
        String url = "http://localhost:8087/employerService"; // URL du service
        EmployerService service = new EmployerServiceImp(); // Création de l'instance du service

        // Publication du service web à l'URL spécifiée
        Endpoint.publish(url, service);

        System.out.println("Service Employer publié à : " + url);
    }
}