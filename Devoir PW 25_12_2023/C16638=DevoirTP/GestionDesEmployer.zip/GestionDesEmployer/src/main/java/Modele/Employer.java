package Modele;



public class Employer {

	
	private int id;
	private String nom;
	private String prenom;
	private String metier;
	public Employer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employer(int id, String nom, String prenom, String metier) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.metier = metier;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getMetier() {
		return metier;
	}
	public void setMetier(String metier) {
		this.metier = metier;
	}
	@Override
	public String toString() {
		return "Employer [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", metier=" + metier + "]";
	}
	
	
	
	
	
}
