package servelt;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.metier.dao.PersonneDoa;
import com.metier.model.Personne;
import com.metier.service.PersoneServiceImp;

import jakarta.xml.ws.Endpoint;

/**
 * Servlet implementation class ServeletApp
 */
@WebServlet(name="/ServeletApp",urlPatterns = { "/Service" })
public class ServeletApp extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession session;

//	String forward = "/WEB-INF/index2.jsp";
	String action;
	boolean update = false;

	/**
	 * Default constructor.
	 */
	public ServeletApp() {
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.setProperty("javax.xml.bind.JAXBContextFactory", "com.sun.xml.bind.v2.ContextFactory");

		String url = "http://localhost:8080/c16627Service";
		Endpoint.publish(url, new PersoneServiceImp());

		System.out.println("Service web CRUD publié avec succès à l'adresse : " + url);
		request.getRequestDispatcher("/WEB-INF/index.jsp").forward(request, response);


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}
}
