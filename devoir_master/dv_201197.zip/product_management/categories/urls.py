
from django.contrib import admin
from django.urls import path
from categories import views as categoriesView

urlpatterns = [
    path('', categoriesView.index, name='categories_index'),
]
