from django.shortcuts import render, redirect
from categories.models import Category
from categories.forms import CategoryForm

# Create your views here.
def index(request):

    context = {}
    form = CategoryForm()
    context['title'] = 'List des categories'
    context['categories'] = Category.objects.all()

    if request.method == 'POST':
        if 'save' in request.POST:
            pk = request.POST.get('save')
            if not pk:
                form = CategoryForm(request.POST)
            else:
                category = Category.objects.get(id=pk)
                form = CategoryForm(request.POST, instance=category)
            form.save()
            form = CategoryForm()
            
        elif 'delete' in request.POST:
            pk = request.POST.get('delete')
            category = Category.objects.get(id=pk)
            category.delete()
        elif 'edit' in request.POST:
            pk = request.POST.get('edit')
            category = Category.objects.get(id=pk)
            form = CategoryForm(instance=category)

    context['form'] = form

    return render(request, 'index.html', context)
