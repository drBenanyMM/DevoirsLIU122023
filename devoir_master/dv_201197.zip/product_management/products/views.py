from django.shortcuts import render, redirect
from products.models import Product
from products.forms import ProductForm

# Create your views here.
def index(request):

    context = {}
    form = ProductForm()
    context['title'] = 'List des products'
    context['products'] = Product.objects.all()

    if request.method == 'POST':
        if 'save' in request.POST:
            pk = request.POST.get('save')
            if not pk:
                form = ProductForm(request.POST)
            else:
                product = Product.objects.get(id=pk)
                form = ProductForm(request.POST, instance=product)
                
            form.save()
            form = ProductForm()
            
        elif 'delete' in request.POST:
            pk = request.POST.get('delete')
            product = Product.objects.get(id=pk)
            product.delete()
        elif 'edit' in request.POST:
            pk = request.POST.get('edit')
            product = Product.objects.get(id=pk)
            form = ProductForm(instance=product)

    context['form'] = form

    return render(request, 'products/index.html', context)
