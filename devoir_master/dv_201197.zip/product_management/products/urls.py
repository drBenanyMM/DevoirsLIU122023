
from django.contrib import admin
from django.urls import path
from products import views as productsView

urlpatterns = [
    path('', productsView.index, name='products_index'),
]
